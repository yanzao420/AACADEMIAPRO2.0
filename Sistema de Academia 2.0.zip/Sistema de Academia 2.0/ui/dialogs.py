from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from ui.widgets import ActionBar, btn


class AppModal(QDialog):
    """Modal base com cabeçalho e rodapé de ações."""

    def __init__(self, parent, titulo, subtitulo="", largura=460):
        super().__init__(parent)
        self.setObjectName("modal")
        self.setWindowTitle(titulo)
        self.setModal(True)
        self.setMinimumWidth(largura)
        self.setMaximumWidth(largura + 80)

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 18)
        root.setSpacing(14)

        titulo_lbl = QLabel(titulo)
        titulo_lbl.setProperty("subheading", True)
        titulo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        titulo_lbl.setAutoFillBackground(False)
        root.addWidget(titulo_lbl)
        if subtitulo:
            sub = QLabel(subtitulo)
            sub.setProperty("muted", True)
            sub.setWordWrap(True)
            sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
            sub.setAutoFillBackground(False)
            root.addWidget(sub)

        self.corpo = QVBoxLayout()
        self.corpo.setSpacing(10)
        root.addLayout(self.corpo)

        self.rodape = QHBoxLayout()
        self.rodape.setSpacing(8)
        self.rodape.addStretch()
        root.addLayout(self.rodape)

    def add_widget(self, widget):
        self.corpo.addWidget(widget)

    def add_layout(self, layout):
        self.corpo.addLayout(layout)

    def add_botao(self, texto, callback, primario=True, secundario=False, perigo=False):
        botao = btn(
            texto,
            callback,
            secondary=secundario or not primario,
            danger=perigo,
        )
        self.rodape.insertWidget(self.rodape.count() - 1, botao)
        return botao


class DetalheModal(AppModal):
    """Modal de detalhes com pares label/valor."""

    def __init__(self, parent, titulo, campos, acoes=None, largura=440):
        super().__init__(parent, titulo, largura=largura)
        for item in campos:
            if len(item) >= 3:
                rotulo, valor, multilinha = item[0], item[1], item[2]
            else:
                rotulo, valor = item[0], item[1]
                multilinha = False
            linha = QWidget()
            row = QVBoxLayout(linha)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(2)
            lbl = QLabel(rotulo)
            lbl.setProperty("field_label", True)
            lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            texto = str(valor)
            if multilinha or "\n" in texto or len(texto) > 70:
                val = QTextEdit()
                val.setReadOnly(True)
                val.setPlainText(texto)
                val.setMinimumHeight(min(220, 48 + 22 * texto.count("\n")))
            else:
                val = QLabel(texto)
                val.setWordWrap(True)
                val.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
                val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            row.addWidget(lbl)
            row.addWidget(val)
            row.setAlignment(Qt.AlignmentFlag.AlignLeft)
            self.add_widget(linha)

        if acoes:
            for texto, callback, estilo in acoes:
                self.add_botao(
                    texto,
                    callback,
                    primario=estilo == "primario",
                    secundario=estilo == "secundario",
                    perigo=estilo == "perigo",
                )
        else:
            self.add_botao("Fechar", self.accept, secundario=True)
