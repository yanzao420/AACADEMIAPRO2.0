import re

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


def btn(text, callback=None, secondary=False, danger=False, nav=False, active=False, cta=False, ghost=False):
    botao = QPushButton(text)
    if secondary:
        botao.setProperty("secondary", True)
    if danger:
        botao.setProperty("danger", True)
    if nav:
        botao.setProperty("nav", True)
    if active:
        botao.setProperty("active", True)
    if cta:
        botao.setProperty("cta", True)
    if ghost:
        botao.setProperty("ghost", True)
    botao.style().unpolish(botao)
    botao.style().polish(botao)
    if callback:
        botao.clicked.connect(lambda _checked=False: callback())
    return botao


def _formatar_data_digitando(texto):
    digitos = re.sub(r"\D", "", texto)[:8]
    if len(digitos) <= 2:
        return digitos
    if len(digitos) <= 4:
        return f"{digitos[:2]}/{digitos[2:]}"
    return f"{digitos[:2]}/{digitos[2:4]}/{digitos[4:]}"


def _aplicar_mascara_data(campo):
    def formatar():
        bruto = campo.text()
        formatado = _formatar_data_digitando(bruto)
        if formatado == bruto:
            return
        pos = campo.cursorPosition()
        digitos_antes = len(re.sub(r"\D", "", bruto[:pos]))
        campo.blockSignals(True)
        campo.setText(formatado)
        nova_pos = 0
        cont = 0
        for i, ch in enumerate(formatado):
            if ch.isdigit():
                cont += 1
            if cont >= digitos_antes:
                nova_pos = i + 1
                break
        else:
            nova_pos = len(formatado)
        campo.setCursorPosition(nova_pos)
        campo.blockSignals(False)

    campo.textChanged.connect(formatar)


class SectionHeader(QWidget):
    def __init__(self, titulo, subtitulo=""):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 12)
        layout.setSpacing(2)
        lbl = QLabel(titulo)
        lbl.setProperty("heading", True)
        layout.addWidget(lbl)
        if subtitulo:
            sub = QLabel(subtitulo)
            sub.setProperty("muted", True)
            layout.addWidget(sub)


class Card(QFrame):
    def __init__(self, parent=None, compacto=False, integrado=False):
        super().__init__(parent)
        self.setObjectName("surface" if integrado else "card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._layout = QVBoxLayout(self)
        margem = 16 if compacto else 20
        self._layout.setContentsMargins(margem, margem, margem, margem)
        self._layout.setSpacing(10)

    def add_widget(self, widget):
        self._layout.addWidget(widget)

    def add_layout(self, layout):
        self._layout.addLayout(layout)


class StatCard(QFrame):
    def __init__(self, titulo, valor, icone=""):
        super().__init__()
        self.setObjectName("stat_card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        topo = QLabel(f"{icone}  {titulo}" if icone else titulo)
        topo.setProperty("stat_title", True)
        topo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        val = QLabel(str(valor))
        val.setProperty("stat_value", True)
        val.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(topo)
        layout.addWidget(val)
        self._valor = val

    def set_valor(self, valor):
        self._valor.setText(str(valor))


class HeroBanner(QFrame):
    def __init__(self, titulo, subtitulo, botao_texto=None, botao_callback=None):
        super().__init__()
        self.setObjectName("hero")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(8)
        h = QLabel(titulo)
        h.setProperty("heading", True)
        h.setAlignment(Qt.AlignmentFlag.AlignCenter)
        h.setAutoFillBackground(False)
        layout.addWidget(h)
        s = QLabel(subtitulo)
        s.setProperty("muted", True)
        s.setWordWrap(True)
        s.setAlignment(Qt.AlignmentFlag.AlignCenter)
        s.setAutoFillBackground(False)
        layout.addWidget(s)
        if botao_texto and botao_callback:
            layout.addSpacing(8)
            layout.addWidget(btn(botao_texto, botao_callback, cta=True), alignment=Qt.AlignmentFlag.AlignLeft)


class FormField(QWidget):
    def __init__(self, rotulo, placeholder="", password=False, mascara_data=None):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self._lbl = QLabel(rotulo)
        self._lbl.setProperty("field_label", True)
        layout.addWidget(self._lbl)
        self.input = QLineEdit()
        self.input.setPlaceholderText(placeholder)
        if password:
            self.input.setEchoMode(QLineEdit.EchoMode.Password)
        usar_mascara = mascara_data if mascara_data is not None else placeholder.upper() == "DD/MM/AAAA"
        if usar_mascara:
            _aplicar_mascara_data(self.input)
        layout.addWidget(self.input)

    def text(self):
        return self.input.text().strip()

    def set_text(self, valor):
        self.input.setText(valor or "")

    def clear(self):
        self.input.clear()

    def set_enabled(self, ativo):
        self.input.setEnabled(ativo)

    def setVisible(self, visivel):
        super().setVisible(visivel)
        self._lbl.setVisible(visivel and bool(self._lbl.text()))


class FieldCombo(QWidget):
    def __init__(self, rotulo):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        lbl = QLabel(rotulo)
        lbl.setProperty("field_label", True)
        layout.addWidget(lbl)
        self.combo = QComboBox()
        layout.addWidget(self.combo)


class MemberSearchPicker(QWidget):
    """Campo de busca para selecionar um membro (substitui combo com lista completa)."""

    def __init__(self, servico_usuarios, rotulo="Membro", placeholder="Buscar por nome, CPF ou e-mail..."):
        super().__init__()
        self.servico = servico_usuarios
        self._cpf = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.busca = FormField(rotulo, placeholder)
        self.busca.input.textChanged.connect(self._filtrar)
        layout.addWidget(self.busca)

        self.lista = QListWidget()
        self.lista.setMaximumHeight(140)
        self.lista.hide()
        self.lista.itemClicked.connect(self._selecionar_item)
        layout.addWidget(self.lista)

        self.lbl_selecionado = QLabel("")
        self.lbl_selecionado.setProperty("accent", True)
        self.lbl_selecionado.hide()
        layout.addWidget(self.lbl_selecionado)

        self.on_selecionado = None

    @property
    def cpf(self):
        return self._cpf

    def limpar(self):
        self._cpf = None
        self.busca.clear()
        self.lista.clear()
        self.lista.hide()
        self.lbl_selecionado.hide()

    def _filtrar(self):
        termo = self.busca.text()
        self.lista.clear()
        if self._cpf and termo != self.lbl_selecionado.text().replace("Selecionado: ", ""):
            self._cpf = None
            self.lbl_selecionado.hide()

        if len(termo.strip()) < 2:
            self.lista.hide()
            return

        from core.servico_usuarios import ServicoUsuarios

        for aluno in self.servico.listar(termo)[:10]:
            rotulo = f"{aluno.nome} — {ServicoUsuarios.formatar_cpf(aluno.cpf)}"
            item = QListWidgetItem(rotulo)
            item.setData(Qt.ItemDataRole.UserRole, aluno.cpf)
            self.lista.addItem(item)

        self.lista.setVisible(self.lista.count() > 0)

    def _selecionar_item(self, item):
        self._cpf = item.data(Qt.ItemDataRole.UserRole)
        self.lbl_selecionado.setText(f"Selecionado: {item.text()}")
        self.lbl_selecionado.show()
        self.lista.hide()
        self.busca.input.blockSignals(True)
        self.busca.set_text(item.text())
        self.busca.input.blockSignals(False)
        if self.on_selecionado:
            self.on_selecionado()


class DataTable(QTableWidget):
    _ALINHO = Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter

    def __init__(self, colunas, headers=None):
        super().__init__(0, len(colunas))
        rotulos = headers or colunas
        self.setHorizontalHeaderLabels(rotulos)
        self.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.setAlternatingRowColors(True)
        self.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.verticalHeader().setVisible(False)
        self.setShowGrid(False)
        self.setMinimumHeight(220)

        cabecalho = self.horizontalHeader()
        cabecalho.setDefaultAlignment(self._ALINHO)
        cabecalho.setStretchLastSection(False)
        cabecalho.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        cabecalho.setHighlightSections(False)

        self.verticalHeader().setDefaultSectionSize(44)

    def set_row(self, row, valores, row_id=None):
        for col, valor in enumerate(valores):
            item = QTableWidgetItem(str(valor))
            item.setTextAlignment(self._ALINHO)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.setItem(row, col, item)
        if row_id is not None and self.item(row, 0):
            self.item(row, 0).setData(Qt.ItemDataRole.UserRole, row_id)

    def clear_rows(self):
        self.setRowCount(0)

    def selected_row_id(self):
        row = self.currentRow()
        if row < 0:
            return None
        item = self.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def bind_double_click(self, callback):
        self.doubleClicked.connect(lambda _: callback())


class ActionBar(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(8)

    def add(self, text, callback, secondary=False, danger=False, cta=False):
        botao = btn(text, lambda: callback(), secondary=secondary, danger=danger, cta=cta)
        self.layout.addWidget(botao)
        return botao

    def add_stretch(self):
        self.layout.addStretch()


class PageToolbar(QWidget):
    def __init__(self, placeholder="Buscar...", acao_texto=None, acao_callback=None):
        super().__init__()
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        self.busca = FormField("", placeholder)
        self.busca._lbl.setVisible(False)
        row.addWidget(self.busca, 1)
        if acao_texto and acao_callback:
            row.addWidget(btn(acao_texto, lambda: acao_callback(), cta=True))

    @property
    def termo(self):
        return self.busca.text()
