from datetime import datetime

from PySide6.QtWidgets import QFileDialog, QLabel, QMessageBox, QStackedWidget, QVBoxLayout, QWidget

from core.excecoes import AcessoNegado, CadastroErro, ValidacaoErro
from core.servico_pagamentos import ServicoPagamentos
from core.servico_planos import ServicoPlanos
from core.servico_usuarios import ServicoUsuarios
from core.util_datas import adicionar_meses
from models.pagamento import Pagamento
from ui.dialogs import AppModal, DetalheModal
from ui.widgets import ActionBar, Card, DataTable, FieldCombo, FormField, PageToolbar


class PagamentosPage(QWidget):
    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.servico = ServicoPagamentos()
        self.servico_usuarios = ServicoUsuarios()
        self.servico_planos = ServicoPlanos()
        self._mapa_alunos = {}
        self._mapa_planos = {}
        self._cache = {}
        self._aluno_atual = None
        self._montar()
        self._atualizar_tabela()

    def ao_exibir(self):
        self.servico.sincronizar_mensalidades()
        self._atualizar_tabela()

    def _montar(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 24)
        layout.setSpacing(12)

        self.toolbar = PageToolbar(
            "Buscar membro...",
            "+  Registrar pagamento",
            self._abrir_modal_registrar,
        )
        self.toolbar.busca.input.textChanged.connect(self._on_busca)
        layout.addWidget(self.toolbar)

        self.stack = QStackedWidget()

        self.view_pastas = QWidget()
        pastas_layout = QVBoxLayout(self.view_pastas)
        pastas_layout.setContentsMargins(0, 0, 0, 0)
        pastas_layout.setSpacing(12)
        card_pastas = Card()
        barra_pastas = ActionBar()
        barra_pastas.add("Abrir pasta", self._abrir_pasta_selecionada, cta=True)
        if self.usuario.pode_gerenciar_pagamentos():
            barra_pastas.add("Gerar mensalidades", self._gerar_mensalidades, secondary=True)
        card_pastas.add_widget(barra_pastas)
        card_pastas.add_widget(
            self._criar_label_info("Pastas por membro — dê duplo clique ou use Abrir pasta.")
        )
        self.tabela_pastas = DataTable(
            ["nome", "cpf", "boletos", "pendentes"],
            ["Membro", "CPF", "Boletos", "Situação"],
        )
        self.tabela_pastas.bind_double_click(self._abrir_pasta_selecionada)
        card_pastas.add_widget(self.tabela_pastas)
        pastas_layout.addWidget(card_pastas, 1)

        self.view_boletos = QWidget()
        boletos_layout = QVBoxLayout(self.view_boletos)
        boletos_layout.setContentsMargins(0, 0, 0, 0)
        boletos_layout.setSpacing(12)

        topo_pasta = ActionBar()
        topo_pasta.add("← Voltar", self._voltar_pastas, secondary=True)
        self.lbl_pasta = QLabel("Pasta do membro")
        self.lbl_pasta.setProperty("subheading", True)
        self.lbl_pasta.setWordWrap(True)
        topo_pasta.layout.addWidget(self.lbl_pasta, 1)

        card_boletos = Card()
        card_boletos.add_widget(topo_pasta)
        barra = ActionBar()
        barra.add("Detalhes", self._detalhe, secondary=True)
        if self.usuario.pode_gerenciar_pagamentos():
            barra.add("Marcar pago", self._marcar_pago, secondary=True)
            barra.add("Remover", self._remover, danger=True)
        card_boletos.add_widget(barra)

        self.tabela = DataTable(
            ["valor", "venc", "status", "desc"],
            ["Valor", "Vencimento", "Status", "Descrição"],
        )
        self.tabela.bind_double_click(self._detalhe)
        card_boletos.add_widget(self.tabela)
        boletos_layout.addWidget(card_boletos, 1)

        self.stack.addWidget(self.view_pastas)
        self.stack.addWidget(self.view_boletos)
        layout.addWidget(self.stack, 1)

    @staticmethod
    def _criar_label_info(texto):
        from PySide6.QtWidgets import QLabel

        lbl = QLabel(texto)
        lbl.setProperty("muted", True)
        lbl.setWordWrap(True)
        return lbl

    def _on_busca(self):
        if self.stack.currentIndex() == 0:
            self._atualizar_pastas()
        else:
            self._atualizar_boletos()

    def _status_label(self, s):
        return {
            Pagamento.STATUS_PAGO: "Pago",
            Pagamento.STATUS_PENDENTE: "Pendente",
            Pagamento.STATUS_ATRASADO: "Atrasado",
        }.get(s, s)

    def _corresponde_aluno(self, cpf, termo):
        if not termo:
            return True
        nome = self.servico.nome_aluno(cpf).lower()
        if termo in nome:
            return True
        digitos = "".join(c for c in termo if c.isdigit())
        return bool(digitos and digitos in cpf)

    def _agrupar_por_aluno(self):
        pagamentos = self.servico.listar()
        self._cache = {p.id: p for p in pagamentos}
        grupos = {}
        for aluno in self.servico_usuarios.listar():
            grupos[aluno.cpf] = []
        for pag in pagamentos:
            grupos.setdefault(pag.aluno_cpf, []).append(pag)
        return grupos

    def _membro_precisa_mensalidades(self, cpf):
        aluno = self.servico_usuarios.buscar_por_cpf(cpf)
        if not aluno or not aluno.plano_id:
            return False
        pagamentos_plano = [
            p
            for p in self._cache.values()
            if p.aluno_cpf == cpf and p.plano_id == aluno.plano_id
        ]
        return len(pagamentos_plano) == 0

    def _texto_situacao_pasta(self, cpf, lista):
        aluno = self.servico_usuarios.buscar_por_cpf(cpf)
        if not aluno or not aluno.plano_id:
            pendentes = sum(1 for p in lista if p.status != Pagamento.STATUS_PAGO)
            if pendentes:
                return f"{pendentes} pendente(s)"
            if lista:
                return "Em dia"
            return "Sem plano"
        if not self.servico_planos.buscar(aluno.plano_id):
            return "Sem plano — vincular"
        pendentes = sum(1 for p in lista if p.status != Pagamento.STATUS_PAGO)
        if self._membro_precisa_mensalidades(cpf):
            return "Sem boleto — gerar"
        if pendentes:
            return f"{pendentes} pendente(s)"
        if lista:
            return "Em dia"
        return "Sem plano"

    def _atualizar_pastas(self):
        self.tabela_pastas.clear_rows()
        termo = self.toolbar.termo.lower()
        grupos = self._agrupar_por_aluno()
        for cpf, lista in sorted(
            grupos.items(),
            key=lambda item: self.servico.nome_aluno(item[0]).lower(),
        ):
            if not self._corresponde_aluno(cpf, termo):
                continue
            row = self.tabela_pastas.rowCount()
            self.tabela_pastas.insertRow(row)
            self.tabela_pastas.set_row(
                row,
                [
                    self.servico.nome_aluno(cpf),
                    ServicoUsuarios.formatar_cpf(cpf),
                    str(len(lista)),
                    self._texto_situacao_pasta(cpf, lista),
                ],
                row_id=cpf,
            )

    def _gerar_mensalidades(self):
        cpf = self.tabela_pastas.selected_row_id()
        if not cpf:
            QMessageBox.warning(self, "Atenção", "Selecione um membro.")
            return

        aluno = self.servico_usuarios.buscar_por_cpf(cpf)
        if not aluno or not aluno.plano_id:
            QMessageBox.warning(
                self,
                "Plano necessário",
                "Este membro não possui plano vinculado.\n\n"
                "Edite o cadastro em Alunos e selecione um plano antes de gerar mensalidades.",
            )
            return
        if not self.servico_planos.buscar(aluno.plano_id):
            QMessageBox.warning(
                self,
                "Plano inválido",
                "O plano vinculado a este membro não existe mais.\n\n"
                "Edite o cadastro em Alunos e selecione um plano válido.",
            )
            return
        if not self._membro_precisa_mensalidades(cpf):
            QMessageBox.information(
                self,
                "Atenção",
                "Este membro já possui mensalidades do plano atual.",
            )
            return

        modal = AppModal(
            self,
            "Gerar mensalidades",
            "Informe o vencimento da 1ª parcela.",
            largura=420,
        )
        c_venc = FormField("1º vencimento", "DD/MM/AAAA")
        hoje = datetime.now().strftime("%d/%m/%Y")
        c_venc.set_text(adicionar_meses(hoje, 1))
        modal.add_widget(c_venc)

        def confirmar():
            try:
                parcelas = self.servico.gerar_mensalidades_para_aluno(
                    cpf,
                    c_venc.text(),
                )
                modal.accept()
                self._atualizar_tabela()
                QMessageBox.information(
                    self,
                    "Sucesso",
                    f"{len(parcelas)} mensalidade(s) gerada(s).\n"
                    f"1º vencimento: {parcelas[0].vencimento}",
                )
            except (ValidacaoErro, CadastroErro, AcessoNegado) as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Gerar", confirmar)
        modal.exec()

    def _abrir_pasta_selecionada(self):
        if self.stack.currentIndex() == 0:
            cpf = self.tabela_pastas.selected_row_id()
        else:
            cpf = self._aluno_atual
        if not cpf:
            QMessageBox.warning(self, "Atenção", "Selecione um membro.")
            return
        self._abrir_pasta(cpf)

    def _abrir_pasta(self, cpf):
        self._aluno_atual = cpf
        nome = self.servico.nome_aluno(cpf)
        cpf_fmt = ServicoUsuarios.formatar_cpf(cpf)
        self.lbl_pasta.setText(f"Pasta: {nome}  •  {cpf_fmt}")
        self.toolbar.busca.input.setPlaceholderText("Buscar boleto nesta pasta...")
        self._atualizar_boletos()
        self.stack.setCurrentIndex(1)

    def _voltar_pastas(self):
        self._aluno_atual = None
        self.toolbar.busca.input.setPlaceholderText("Buscar membro...")
        self.toolbar.busca.clear()
        self.stack.setCurrentIndex(0)
        self._atualizar_pastas()

    def _atualizar_boletos(self):
        self.tabela.clear_rows()
        if not self._aluno_atual:
            return
        termo = self.toolbar.termo.lower()
        pagamentos = [
            p for p in self._cache.values() if p.aluno_cpf == self._aluno_atual
        ]
        pagamentos.sort(key=lambda p: p.vencimento)
        for pag in pagamentos:
            texto = " ".join(
                [
                    pag.descricao or "",
                    pag.vencimento,
                    self._status_label(pag.status),
                    f"{pag.valor:.2f}",
                ]
            ).lower()
            if termo and termo not in texto:
                continue
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            self.tabela.set_row(
                row,
                [
                    f"R$ {pag.valor:.2f}".replace(".", ","),
                    pag.vencimento,
                    self._status_label(pag.status),
                    pag.descricao or "—",
                ],
                row_id=pag.id,
            )

    def _atualizar_tabela(self):
        self._cache = {p.id: p for p in self.servico.listar()}
        if self.stack.currentIndex() == 0:
            self._atualizar_pastas()
        else:
            self._atualizar_boletos()

    def _atualizar_combos(self, c_aluno, c_plano):
        c_aluno.combo.clear()
        c_plano.combo.clear()
        self._mapa_alunos = {}
        self._mapa_planos = {"Sem plano": None}
        c_plano.combo.addItem("Sem plano")
        for aluno in self.servico_usuarios.listar(apenas_ativos=True):
            lbl = f"{aluno.nome} — {ServicoUsuarios.formatar_cpf(aluno.cpf)}"
            self._mapa_alunos[lbl] = aluno.cpf
            c_aluno.combo.addItem(lbl)
        for p in self.servico_planos.listar():
            lbl = f"{p.nome} — {ServicoPlanos.formatar_valor(p.valor)}"
            self._mapa_planos[lbl] = p.id
            c_plano.combo.addItem(lbl)

    def _abrir_modal_registrar(self):
        if not self.usuario.pode_gerenciar_pagamentos():
            QMessageBox.warning(self, "Atenção", "Sem permissão.")
            return
        modal = AppModal(self, "Registrar pagamento", "Nova mensalidade ou cobrança.", largura=440)
        c_aluno = FieldCombo("Membro")
        c_plano = FieldCombo("Plano (opcional)")
        c_valor = FormField("Valor (R$)", "0,00")
        c_venc = FormField("Vencimento", "DD/MM/AAAA")
        c_desc = FormField("Descrição", "MENSALIDADE")
        c_desc.set_text("MENSALIDADE")
        self._atualizar_combos(c_aluno, c_plano)

        if self._aluno_atual:
            for lbl, cpf in self._mapa_alunos.items():
                if cpf == self._aluno_atual:
                    c_aluno.combo.setCurrentText(lbl)
                    break

        def ao_aluno():
            cpf = self._mapa_alunos.get(c_aluno.combo.currentText())
            if not cpf:
                return
            aluno = self.servico_usuarios.buscar_por_cpf(cpf)
            if aluno and aluno.plano_id:
                for lbl, pid in self._mapa_planos.items():
                    if pid == aluno.plano_id:
                        c_plano.combo.setCurrentText(lbl)
                        ao_plano()
                        break

        def ao_plano():
            pid = self._mapa_planos.get(c_plano.combo.currentText())
            if pid:
                p = self.servico_planos.buscar(pid)
                if p:
                    c_valor.set_text(str(p.valor).replace(".", ","))

        c_aluno.combo.currentIndexChanged.connect(ao_aluno)
        c_plano.combo.currentIndexChanged.connect(ao_plano)
        for w in (c_aluno, c_plano, c_valor, c_venc, c_desc):
            modal.add_widget(w)

        def registrar():
            try:
                cpf = self._mapa_alunos.get(c_aluno.combo.currentText())
                if not cpf:
                    QMessageBox.warning(modal, "Atenção", "Selecione um membro.")
                    return
                self.servico.registrar(
                    aluno_cpf=cpf,
                    valor=c_valor.text(),
                    vencimento=c_venc.text(),
                    plano_id=self._mapa_planos.get(c_plano.combo.currentText()),
                    descricao=c_desc.text() or "MENSALIDADE",
                    usuario=self.usuario,
                )
                modal.accept()
                self._atualizar_tabela()
                QMessageBox.information(self, "Sucesso", "Pagamento registrado!")
            except (ValidacaoErro, CadastroErro, AcessoNegado) as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Registrar", registrar)
        modal.exec()

    def _detalhe(self):
        pid = self.tabela.selected_row_id()
        pag = self._cache.get(pid)
        if not pag:
            QMessageBox.warning(self, "Atenção", "Selecione um pagamento.")
            return
        modal = DetalheModal(
            self,
            "Detalhe do pagamento",
            [
                ("Membro", self.servico.nome_aluno(pag.aluno_cpf)),
                ("Valor", f"R$ {pag.valor:.2f}".replace(".", ",")),
                ("Vencimento", pag.vencimento),
                ("Status", self._status_label(pag.status)),
                ("Descrição", pag.descricao or "—"),
            ],
        )
        if self.usuario.pode_gerenciar_pagamentos() and pag.status != Pagamento.STATUS_PAGO:
            modal.add_botao("Marcar pago", self._marcar_pago, secundario=True)
        modal.exec()

    def _marcar_pago(self):
        pid = self.tabela.selected_row_id()
        if not pid:
            QMessageBox.warning(self, "Atenção", "Selecione um pagamento.")
            return
        try:
            pagamento = self.servico.marcar_como_pago(pid, usuario=self.usuario)
            self._atualizar_tabela()
            msg = "Marcado como pago."
            proximo = getattr(pagamento, "proximo_mensalidade", None)
            if proximo:
                msg += f"\nPróxima mensalidade gerada: {proximo.vencimento}"
            QMessageBox.information(self, "Sucesso", msg)
        except (CadastroErro, AcessoNegado) as e:
            QMessageBox.critical(self, "Erro", str(e))

    def _remover(self):
        pid = self.tabela.selected_row_id()
        if not pid:
            QMessageBox.warning(self, "Atenção", "Selecione um pagamento.")
            return
        if QMessageBox.question(self, "Confirmar", "Remover pagamento?") != QMessageBox.StandardButton.Yes:
            return
        try:
            self.servico.remover(pid, usuario=self.usuario)
            self._atualizar_tabela()
            QMessageBox.information(self, "Sucesso", "Removido.")
        except (CadastroErro, AcessoNegado) as e:
            QMessageBox.critical(self, "Erro", str(e))
