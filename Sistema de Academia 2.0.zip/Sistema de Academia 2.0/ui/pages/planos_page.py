from PySide6.QtWidgets import QMessageBox, QVBoxLayout, QWidget

from core.excecoes import AcessoNegado, CadastroErro, ValidacaoErro
from core.servico_planos import ServicoPlanos
from ui.dialogs import AppModal, DetalheModal
from ui.widgets import ActionBar, Card, DataTable, FormField, PageToolbar


class PlanosPage(QWidget):
    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.servico = ServicoPlanos()
        self._montar()
        self._atualizar_tabela()

    def ao_exibir(self):
        self._atualizar_tabela()

    def _montar(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 24)
        layout.setSpacing(12)

        self.toolbar = PageToolbar("Buscar plano...", "+  Novo plano", self._abrir_modal_novo)
        self.toolbar.busca.input.textChanged.connect(self._atualizar_tabela)
        layout.addWidget(self.toolbar)

        card = Card()
        barra = ActionBar()
        barra.add("Detalhes", self._detalhes, secondary=True)
        if self.usuario.pode_gerenciar_planos():
            barra.add("Editar", self._editar, secondary=True)
            barra.add("Remover", self._remover, danger=True)
        card.add_widget(barra)

        self.tabela = DataTable(
            ["nome", "valor", "duracao"],
            ["Nome", "Valor", "Duração"],
        )
        self.tabela.bind_double_click(self._detalhes)
        card.add_widget(self.tabela)
        layout.addWidget(card, 1)

    def _abrir_modal_novo(self, plano=None):
        if isinstance(plano, bool) or not (plano is not None and hasattr(plano, "id")):
            plano = None
        modal = AppModal(
            self,
            "Editar plano" if plano else "Novo plano",
            "Preencha os dados do plano de mensalidade.",
        )
        campo_nome = FormField("Nome do plano", "Ex.: Mensal Premium")
        campo_valor = FormField("Valor (R$)", "99,90")
        campo_dur = FormField("Duração (meses)", "1")
        if plano:
            campo_nome.set_text(plano.nome)
            campo_valor.set_text(str(plano.valor).replace(".", ","))
            campo_dur.set_text(str(plano.duracao_meses))
        else:
            campo_dur.set_text("1")

        for c in (campo_nome, campo_valor, campo_dur):
            modal.add_widget(c)

        def salvar():
            try:
                if plano:
                    self.servico.atualizar(
                        plano.id,
                        campo_nome.text(),
                        campo_valor.text(),
                        campo_dur.text(),
                        usuario=self.usuario,
                    )
                else:
                    self.servico.cadastrar(
                        campo_nome.text(),
                        campo_valor.text(),
                        campo_dur.text(),
                        usuario=self.usuario,
                    )
                modal.accept()
                self._atualizar_tabela()
                QMessageBox.information(self, "Sucesso", "Plano salvo!")
            except (ValidacaoErro, CadastroErro, AcessoNegado) as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Salvar", salvar)
        modal.exec()

    def _atualizar_tabela(self):
        self.tabela.clear_rows()
        termo = self.toolbar.termo.lower()
        for p in self.servico.listar():
            if termo and termo not in p.nome.lower():
                continue
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            self.tabela.set_row(
                row,
                [p.nome, ServicoPlanos.formatar_valor(p.valor), f"{p.duracao_meses} meses"],
                row_id=p.id,
            )

    def _plano_sel(self):
        pid = self.tabela.selected_row_id()
        return self.servico.buscar(pid) if pid else None

    def _detalhes(self):
        p = self._plano_sel()
        if not p:
            QMessageBox.warning(self, "Atenção", "Selecione um plano.")
            return
        modal = DetalheModal(
            self,
            p.nome,
            [
                ("Valor", ServicoPlanos.formatar_valor(p.valor)),
                ("Duração", f"{p.duracao_meses} meses"),
            ],
        )
        if self.usuario.pode_gerenciar_planos():
            modal.add_botao("Editar", self._editar, secundario=True)
        modal.exec()

    def _editar(self):
        p = self._plano_sel()
        if not p:
            QMessageBox.warning(self, "Atenção", "Selecione um plano.")
            return
        self._abrir_modal_novo(p)

    def _remover(self):
        pid = self.tabela.selected_row_id()
        if not pid:
            QMessageBox.warning(self, "Atenção", "Selecione um plano.")
            return
        if QMessageBox.question(
            self,
            "Confirmar",
            "Remover plano do catálogo?\n\n"
            "Membros vinculados ficarão sem plano e todos os boletos "
            "desse plano serão excluídos.",
        ) != QMessageBox.StandardButton.Yes:
            return
        try:
            self.servico.remover(pid, usuario=self.usuario)
            self._atualizar_tabela()
            QMessageBox.information(
                self,
                "Sucesso",
                "Plano removido. Vínculos e boletos relacionados foram limpos.",
            )
        except (CadastroErro, AcessoNegado) as e:
            QMessageBox.critical(self, "Erro", str(e))
