from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFileDialog, QLabel, QListWidget, QListWidgetItem, QMessageBox, QTextEdit, QVBoxLayout, QWidget

from core.excecoes import CadastroErro, ValidacaoErro
from core.exportar_treino_pdf import exportar_treinos_aluno
from core.servico_treinos import ServicoTreinos
from core.servico_usuarios import ServicoUsuarios
from ui.dialogs import AppModal, DetalheModal
from ui.widgets import ActionBar, Card, DataTable, FormField, MemberSearchPicker, PageToolbar


class TreinosPage(QWidget):
    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.servico = ServicoTreinos()
        self.servico_usuarios = ServicoUsuarios()
        self._montar()
        self._atualizar_catalogo()

    def ao_exibir(self):
        self._atualizar_catalogo()

    def _montar(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 24)
        layout.setSpacing(12)

        topo = ActionBar()
        self.toolbar = PageToolbar("Buscar treino...", "+  Vincular ao membro", self._abrir_modal_vincular)
        self.toolbar.busca.input.textChanged.connect(self._atualizar_catalogo)
        topo.layout.addWidget(self.toolbar, 1)
        topo.add("+  Novo treino", self._abrir_modal_novo_treino, cta=True)
        layout.addWidget(topo)

        card = Card()
        barra = ActionBar()
        barra.add("Detalhes", self._detalhe_treino, secondary=True)
        barra.add("Editar", self._editar_treino, secondary=True)
        barra.add("Treinos do membro", self._modal_membro, secondary=True)
        if self.usuario.pode_remover():
            barra.add("Remover", self._remover_treino, danger=True)
        card.add_widget(barra)

        self.tabela = DataTable(
            ["nome", "duracao", "desc"],
            ["Treino", "Duração", "Descrição"],
        )
        self.tabela.bind_double_click(self._editar_treino)
        card.add_widget(self.tabela)
        layout.addWidget(card, 1)

    def _atualizar_catalogo(self):
        self.tabela.clear_rows()
        termo = self.toolbar.termo.lower()
        for t in self.servico.listar_catalogo():
            if termo and termo not in t.nome.lower() and termo not in (t.descricao or "").lower():
                continue
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            self.tabela.set_row(
                row,
                [t.nome, f"{t.duracao_minutos} min", t.descricao or "—"],
                row_id=t.id,
            )

    def _treino_selecionado(self):
        tid = self.tabela.selected_row_id()
        return self.servico.buscar_no_catalogo(tid) if tid else None

    def _abrir_modal_novo_treino(self):
        modal = AppModal(
            self,
            "Novo treino",
            "Cadastre uma ficha no catálogo para vincular aos membros.",
            largura=480,
        )
        c_nome = FormField("Nome do treino", "Ex.: Peito e Tríceps")
        c_duracao = FormField("Duração (minutos)", "60")
        c_duracao.set_text("60")
        c_desc = QTextEdit()
        c_desc.setPlaceholderText("Descreva os exercícios, séries e orientações do treino.")
        c_desc.setMaximumHeight(120)
        modal.add_widget(c_nome)
        modal.add_widget(c_duracao)
        lbl_desc = QLabel("Descrição")
        lbl_desc.setProperty("field_label", True)
        modal.add_widget(lbl_desc)
        modal.add_widget(c_desc)

        def salvar():
            try:
                self.servico.cadastrar_catalogo(
                    nome=c_nome.text(),
                    duracao_minutos=c_duracao.text(),
                    descricao=c_desc.toPlainText(),
                    usuario=self.usuario,
                )
                modal.accept()
                self._atualizar_catalogo()
                QMessageBox.information(self, "Sucesso", "Treino cadastrado no catálogo!")
            except (ValidacaoErro, CadastroErro) as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Salvar", salvar)
        modal.exec()

    def _detalhe_treino(self):
        treino = self._treino_selecionado()
        if not treino:
            QMessageBox.warning(self, "Atenção", "Selecione um treino.")
            return
        modal = DetalheModal(
            self,
            treino.nome,
            [
                ("Duração", f"{treino.duracao_minutos} minutos"),
                ("Descrição", treino.descricao or "—"),
            ],
        )
        modal.add_botao("Vincular", self._abrir_modal_vincular, secundario=True)
        modal.add_botao("Editar", self._editar_treino, secundario=True)
        modal.exec()

    def _editar_treino(self):
        treino = self._treino_selecionado()
        if not treino:
            QMessageBox.warning(self, "Atenção", "Selecione um treino.")
            return
        modal = AppModal(
            self,
            "Editar treino",
            "Altere nome, duração e descrição da ficha no catálogo.",
            largura=480,
        )
        c_nome = FormField("Nome do treino")
        c_nome.set_text(treino.nome)
        c_duracao = FormField("Duração (minutos)")
        c_duracao.set_text(str(treino.duracao_minutos))
        c_desc = QTextEdit()
        c_desc.setPlaceholderText("Descreva os exercícios, séries e orientações do treino.")
        c_desc.setPlainText(treino.descricao or "")
        c_desc.setMaximumHeight(120)
        modal.add_widget(c_nome)
        modal.add_widget(c_duracao)
        lbl_desc = QLabel("Descrição")
        lbl_desc.setProperty("field_label", True)
        modal.add_widget(lbl_desc)
        modal.add_widget(c_desc)

        def salvar():
            try:
                self.servico.atualizar_catalogo(
                    id_treino=treino.id,
                    nome=c_nome.text(),
                    duracao_minutos=c_duracao.text(),
                    descricao=c_desc.toPlainText(),
                    usuario=self.usuario,
                )
                modal.accept()
                self._atualizar_catalogo()
                QMessageBox.information(self, "Sucesso", "Treino atualizado!")
            except (ValidacaoErro, CadastroErro) as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Salvar", salvar)
        modal.exec()

    def _remover_treino(self):
        treino = self._treino_selecionado()
        if not treino:
            QMessageBox.warning(self, "Atenção", "Selecione um treino.")
            return
        msg = (
            f"Remover o treino \"{treino.nome}\" do catálogo?\n\n"
            "Todos os vínculos com membros também serão excluídos."
        )
        if QMessageBox.question(self, "Confirmar", msg) != QMessageBox.StandardButton.Yes:
            return
        try:
            self.servico.remover_catalogo(treino.id, usuario=self.usuario)
            self._atualizar_catalogo()
            QMessageBox.information(
                self,
                "Sucesso",
                "Treino removido do catálogo e desvinculado de todos os membros.",
            )
        except CadastroErro as e:
            QMessageBox.critical(self, "Erro", str(e))

    def _abrir_modal_vincular(self):
        tid = self.tabela.selected_row_id()
        modal = AppModal(self, "Vincular treino", "Busque e selecione o membro para receber a ficha.")
        picker = MemberSearchPicker(self.servico_usuarios)
        modal.add_widget(picker)

        if tid:
            treino = self.servico.buscar_no_catalogo(tid)
            if treino:
                info = QLabel(f"Treino: <b>{treino.nome}</b>")
                modal.corpo.insertWidget(0, info)

        def vincular():
            cpf = picker.cpf
            treino_id = tid or self.tabela.selected_row_id()
            if not cpf or not treino_id:
                QMessageBox.warning(modal, "Atenção", "Busque e selecione um membro e um treino.")
                return
            try:
                self.servico.adicionar_treino_ao_aluno(cpf, treino_id, usuario=self.usuario)
                modal.accept()
                QMessageBox.information(self, "Sucesso", "Treino vinculado!")
            except CadastroErro as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Vincular", vincular)
        modal.exec()

    def _modal_membro(self):
        modal = AppModal(self, "Treinos do membro", "Busque o membro para visualizar, remover ou exportar.", largura=480)
        picker = MemberSearchPicker(self.servico_usuarios)
        modal.add_widget(picker)
        lbl_lista = QLabel("Treinos vinculados")
        lbl_lista.setProperty("field_label", True)
        modal.add_widget(lbl_lista)
        lista_treinos = QListWidget()
        lista_treinos.setMaximumHeight(160)
        modal.add_widget(lista_treinos)
        info_lbl = QLabel("Busque e selecione um membro.")
        info_lbl.setWordWrap(True)
        info_lbl.setProperty("muted", True)
        modal.add_widget(info_lbl)

        def atualizar():
            cpf = picker.cpf
            lista_treinos.clear()
            if not cpf:
                info_lbl.setText("Busque e selecione um membro.")
                return
            treinos = self.servico.treinos_do_aluno(cpf)
            if not treinos:
                info_lbl.setText("Nenhum treino vinculado.")
                return
            info_lbl.setText(f"{len(treinos)} treino(s) — selecione um para remover.")
            for t in treinos:
                item = QListWidgetItem(f"{t.nome} ({t.duracao_minutos} min)")
                item.setData(Qt.ItemDataRole.UserRole, t.id)
                item.setToolTip(t.descricao or "Sem descrição.")
                lista_treinos.addItem(item)

        picker.on_selecionado = atualizar

        def exportar():
            cpf = picker.cpf
            if not cpf:
                QMessageBox.warning(modal, "Atenção", "Selecione um membro.")
                return
            aluno = self.servico_usuarios.buscar_por_cpf(cpf)
            treinos = self.servico.treinos_do_aluno(cpf)
            if not treinos:
                QMessageBox.warning(modal, "Atenção", "Nenhum treino vinculado.")
                return
            caminho, _ = QFileDialog.getSaveFileName(
                modal, "Salvar PDF", f"treino_{aluno.nome.replace(' ', '_')}.pdf", "PDF (*.pdf)"
            )
            if caminho:
                try:
                    exportar_treinos_aluno(aluno, treinos, caminho)
                    QMessageBox.information(modal, "Sucesso", f"PDF salvo:\n{caminho}")
                except Exception as e:
                    QMessageBox.critical(modal, "Erro", str(e))

        def remover():
            cpf = picker.cpf
            item = lista_treinos.currentItem()
            if not cpf or not item:
                QMessageBox.warning(modal, "Atenção", "Selecione um membro e um treino.")
                return
            treino_id = item.data(Qt.ItemDataRole.UserRole)
            nome = item.text()
            if (
                QMessageBox.question(
                    modal,
                    "Confirmar",
                    f"Remover o treino \"{nome}\" deste membro?",
                )
                != QMessageBox.StandardButton.Yes
            ):
                return
            try:
                self.servico.remover_treino_do_aluno(cpf, treino_id, usuario=self.usuario)
                atualizar()
                QMessageBox.information(modal, "Sucesso", "Treino desvinculado do membro.")
            except CadastroErro as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Exportar PDF", exportar, secundario=True)
        modal.add_botao("Remover selecionado", remover, secundario=True)
        modal.add_botao("Fechar", modal.accept, secundario=True)
        modal.exec()
