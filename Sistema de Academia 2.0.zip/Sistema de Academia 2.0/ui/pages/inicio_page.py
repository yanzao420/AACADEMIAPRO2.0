import shutil
from datetime import datetime
from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QGridLayout, QLabel, QMessageBox, QVBoxLayout, QWidget

from core.repositorio import ARQUIVO_DB, RepositorioAcademia
from core.servico_dashboard import ServicoDashboard
from ui.widgets import ActionBar, Card, SectionHeader, StatCard, btn


class InicioPage(QWidget):
    _STATS = [
        ("Membros ativos", "👤"),
        ("Instrutores", "🏋"),
        ("Planos", "💎"),
        ("Pendentes", "⏳"),
        ("Atrasados", "⚠"),
    ]

    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.repo = RepositorioAcademia()
        self.servico = ServicoDashboard(self.repo)
        self._stat_cards = []
        self._ir_para_rotas = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 24)
        layout.setSpacing(16)

        layout.addWidget(
            SectionHeader(
                "Painel da academia",
                "Resumo operacional — membros, financeiro e alertas.",
            )
        )

        if self.usuario.pode_exportar():
            barra = ActionBar()
            barra.add("Exportar backup", self._exportar_backup, secondary=True)
            layout.addWidget(barra)

        self.stats = QGridLayout()
        self.stats.setSpacing(12)
        for i, (titulo, icone) in enumerate(self._STATS):
            card = StatCard(titulo, 0, icone)
            self._stat_cards.append(card)
            self.stats.addWidget(card, 0, i)
        layout.addLayout(self.stats)

        self.lbl_financeiro = QLabel("Financeiro: —")
        self.lbl_financeiro.setProperty("subheading", True)
        self.lbl_financeiro.setWordWrap(True)
        layout.addWidget(self.lbl_financeiro)

        card_alertas = Card()
        titulo_alertas = QLabel("Alertas")
        titulo_alertas.setProperty("heading", True)
        card_alertas.add_widget(titulo_alertas)
        self.alertas_layout = QVBoxLayout()
        self.alertas_layout.setSpacing(8)
        card_alertas.add_layout(self.alertas_layout)
        layout.addWidget(card_alertas)

        layout.addStretch()
        self.ao_exibir()

    def vincular_dashboard(self, ir_para_rotas):
        self._ir_para_rotas = ir_para_rotas

    def _ir_para(self, nome):
        if self._ir_para_rotas:
            self._ir_para_rotas(nome)

    def _exportar_backup(self):
        stamp = datetime.now().strftime("%Y%m%d_%H%M")
        sugestao = f"academia_backup_{stamp}.db"
        caminho, _ = QFileDialog.getSaveFileName(
            self,
            "Exportar backup",
            sugestao,
            "Banco SQLite (*.db)",
        )
        if not caminho:
            return
        destino = Path(caminho)
        if destino.suffix.lower() != ".db":
            destino = destino.with_suffix(".db")
        try:
            if getattr(self.repo, "_usa_compartilhado", False):
                self.repo._conexao.commit()
            shutil.copy2(ARQUIVO_DB, destino)
            QMessageBox.information(
                self,
                "Sucesso",
                f"Backup salvo em:\n{destino}",
            )
        except OSError as e:
            QMessageBox.critical(self, "Erro", f"Não foi possível salvar o backup.\n{e}")

    def _limpar_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def _atualizar_alertas(self, alertas):
        self._limpar_layout(self.alertas_layout)

        itens = []
        n_atraso = alertas["membros_com_atraso"]
        n_sem_plano = alertas["membros_sem_plano"]

        if n_atraso:
            texto = f"{n_atraso} membro(s) com boleto atrasado"
            itens.append(("Pagamentos", texto))
        if n_sem_plano:
            texto = f"{n_sem_plano} membro(s) sem plano vinculado"
            itens.append(("Membros", texto))

        if not itens:
            lbl = QLabel("Nenhum alerta no momento.")
            lbl.setProperty("muted", True)
            self.alertas_layout.addWidget(lbl)
            return

        for destino, texto in itens:
            self.alertas_layout.addWidget(
                btn(
                    f"→  {texto}",
                    lambda d=destino: self._ir_para(d),
                    ghost=True,
                )
            )

    def ao_exibir(self):
        dados = self.servico.obter_dados()
        resumo = dados["resumo"]

        valores = [
            resumo["alunos_ativos"],
            resumo["instrutores"],
            resumo["total_planos"],
            resumo["pagamentos_pendentes"],
            resumo["pagamentos_atrasados"],
        ]
        for card, valor in zip(self._stat_cards, valores):
            card.set_valor(valor)

        receita = ServicoDashboard.formatar_moeda(resumo["receita_recebida"])
        self.lbl_financeiro.setText(
            f"Financeiro: {receita} recebidos · "
            f"{resumo['pagamentos_atrasados']} atrasado(s) · "
            f"{resumo['pagamentos_pendentes']} pendente(s)"
        )

        self._atualizar_alertas(dados["alertas"])
