from datetime import datetime

from PySide6.QtWidgets import QFileDialog, QCheckBox, QMessageBox, QTextEdit, QVBoxLayout, QWidget

from core.excecoes import AcessoNegado, CadastroErro, ValidacaoErro
from core.exportar_treino_pdf import exportar_treinos_aluno
from core.servico_instrutores import ServicoInstrutores
from core.servico_pagamentos import ServicoPagamentos
from core.servico_planos import ServicoPlanos
from core.servico_treinos import ServicoTreinos
from core.servico_usuarios import ServicoUsuarios
from core.util_datas import adicionar_meses
from ui.dialogs import AppModal, DetalheModal
from ui.widgets import ActionBar, Card, DataTable, FieldCombo, FormField, PageToolbar


class AlunosPage(QWidget):
    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.servico = ServicoUsuarios()
        self.servico_planos = ServicoPlanos()
        self.servico_instr = ServicoInstrutores()
        self.servico_pag = ServicoPagamentos()
        self.servico_treinos = ServicoTreinos()
        self._mapa_planos = {}
        self._mapa_instr = {}
        self._montar()
        self._atualizar_tabela()

    def ao_exibir(self):
        self.servico_pag.sincronizar_mensalidades()
        self._atualizar_tabela()

    def _montar(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 24)
        layout.setSpacing(12)

        self.toolbar = PageToolbar("Buscar membro...", "+  Novo membro", self._abrir_modal_novo)
        self.toolbar.busca.input.textChanged.connect(self._atualizar_tabela)
        layout.addWidget(self.toolbar)

        self.chk_ativos = QCheckBox("Somente ativos")
        self.chk_ativos.setChecked(False)
        self.chk_ativos.stateChanged.connect(self._atualizar_tabela)
        layout.addWidget(self.chk_ativos)

        card = Card()
        barra = ActionBar()
        barra.add("Detalhes", self._detalhes, secondary=True)
        barra.add("Editar", self._editar, secondary=True)
        barra.add("Status", self._alternar_status, secondary=True)
        if self.usuario.pode_remover():
            barra.add("Remover", self._remover, danger=True)
        card.add_widget(barra)

        self.tabela = DataTable(
            ["nome", "cpf", "plano", "cadastro", "pagamento", "tel"],
            ["Nome", "CPF", "Plano", "Cadastro", "Pagamento", "Telefone"],
        )
        self.tabela.bind_double_click(self._detalhes)
        card.add_widget(self.tabela)
        layout.addWidget(card, 1)

    def _atualizar_combos(self, combo_plano, combo_instr):
        combo_plano.combo.clear()
        combo_instr.combo.clear()
        self._mapa_planos = {"Sem plano": None}
        self._mapa_instr = {"Sem instrutor": None}
        combo_plano.combo.addItem("Sem plano")
        combo_instr.combo.addItem("Sem instrutor")
        for p in self.servico_planos.listar():
            lbl = f"{p.nome} — {ServicoPlanos.formatar_valor(p.valor)}"
            self._mapa_planos[lbl] = p.id
            combo_plano.combo.addItem(lbl)
        for i in self.servico_instr.listar():
            lbl = f"{i.nome} — {ServicoUsuarios.formatar_cpf(i.cpf)}"
            self._mapa_instr[lbl] = i.cpf
            combo_instr.combo.addItem(lbl)

    def _abrir_modal_novo(self, aluno=None):
        if isinstance(aluno, bool) or not (aluno is not None and hasattr(aluno, "cpf")):
            aluno = None
        modal = AppModal(
            self,
            "Editar membro" if aluno else "Novo membro",
            "Cadastro completo do aluno da academia.",
            largura=480,
        )
        c_nome = FormField("Nome completo")
        c_cpf = FormField("CPF")
        c_nasc = FormField("Nascimento", "DD/MM/AAAA")
        c_email = FormField("E-mail")
        c_tel = FormField("Telefone")
        c_plano = FieldCombo("Plano")
        c_instr = FieldCombo("Instrutor")
        c_venc = FormField("1º vencimento", "DD/MM/AAAA")
        c_status = FieldCombo("Status 1ª parcela")
        c_status.combo.addItems(["Pendente", "Pago", "Atrasado"])
        c_obs = QTextEdit()
        c_obs.setPlaceholderText("Observações (opcional)")
        c_obs.setMaximumHeight(70)
        chk = QCheckBox("Aluno ativo")
        chk.setChecked(True)

        self._atualizar_combos(c_plano, c_instr)
        editando = aluno is not None
        cpf_edicao = aluno.cpf.strip() if editando else ""
        plano_original = aluno.plano_id if aluno else None

        if aluno:
            c_nome.set_text(aluno.nome)
            c_cpf.set_text(ServicoUsuarios.formatar_cpf(aluno.cpf))
            c_cpf.set_enabled(False)
            c_nasc.set_text(aluno.data_nascimento)
            c_email.set_text(aluno.email)
            c_tel.set_text(ServicoUsuarios.formatar_telefone(aluno.telefone))
            c_obs.setPlainText(aluno.observacoes or "")
            chk.setChecked(aluno.ativo)
            for lbl, pid in self._mapa_planos.items():
                if pid == aluno.plano_id:
                    c_plano.combo.setCurrentText(lbl)
                    break
            for lbl, cpf in self._mapa_instr.items():
                if cpf == aluno.instrutor_cpf:
                    c_instr.combo.setCurrentText(lbl)
                    break
            c_venc.setVisible(False)
            c_status.setVisible(False)

        def _plano_selecionado():
            return self._mapa_planos.get(c_plano.combo.currentText())

        def _plano_mudou():
            return editando and _plano_selecionado() != plano_original

        def _faltam_boletos():
            if not editando or not cpf_edicao:
                return False
            plano_atual = _plano_selecionado()
            if not plano_atual:
                return False
            pagamentos = self.servico_pag._pagamentos_do_aluno(cpf_edicao)
            return not any(p.plano_id == plano_atual for p in pagamentos)

        def ao_plano():
            tem_plano = _plano_selecionado() is not None
            mostrar_fin = (
                (not editando and tem_plano)
                or (_plano_mudou() and tem_plano)
                or (_faltam_boletos() and tem_plano)
            )
            c_venc.setVisible(mostrar_fin)
            c_status.setVisible(mostrar_fin)
            if mostrar_fin and not c_venc.text().strip():
                hoje = datetime.now().strftime("%d/%m/%Y")
                c_venc.set_text(adicionar_meses(hoje, 1))

        c_plano.combo.currentIndexChanged.connect(ao_plano)
        ao_plano()

        for w in (c_nome, c_cpf, c_nasc, c_email, c_tel, c_plano, c_instr, c_venc, c_status):
            modal.add_widget(w)
        modal.add_widget(c_obs)
        modal.add_widget(chk)

        def salvar():
            try:
                plano_id = _plano_selecionado()
                instr_cpf = self._mapa_instr.get(c_instr.combo.currentText())
                mapa_st = {"Pago": "pago", "Pendente": "pendente", "Atrasado": "atrasado"}
                precisa_vencimento = (
                    (not editando and plano_id)
                    or (_plano_mudou() and plano_id)
                    or (_faltam_boletos() and plano_id)
                )
                if precisa_vencimento and not c_venc.text().strip():
                    QMessageBox.warning(
                        modal,
                        "Atenção",
                        "Informe a data do 1º vencimento para gerar as mensalidades.",
                    )
                    return
                if editando:
                    extra = {}
                    if plano_id and (_plano_mudou() or _faltam_boletos()):
                        extra["data_primeiro_vencimento"] = c_venc.text()
                        extra["status_pagamento"] = mapa_st.get(
                            c_status.combo.currentText(), "pendente"
                        )
                    membro = self.servico.atualizar(
                        cpf=cpf_edicao,
                        nome=c_nome.text(),
                        data_nascimento=c_nasc.text(),
                        email=c_email.text(),
                        telefone=c_tel.text(),
                        observacoes=c_obs.toPlainText(),
                        plano_id=plano_id,
                        instrutor_cpf=instr_cpf,
                        ativo=chk.isChecked(),
                        usuario=self.usuario,
                        **extra,
                    )
                    msg = "Membro atualizado!"
                    qtd = getattr(membro, "parcelas_geradas", 0)
                    if _plano_mudou() and not plano_id:
                        msg += "\nBoletos antigos removidos."
                    elif qtd:
                        if _plano_mudou():
                            msg += "\nBoletos antigos removidos."
                        msg += f"\n{qtd} nova(s) mensalidade(s) gerada(s)."
                else:
                    extra = {"plano_id": plano_id, "instrutor_cpf": instr_cpf}
                    if plano_id:
                        extra["data_primeiro_vencimento"] = c_venc.text()
                        extra["status_pagamento"] = mapa_st.get(c_status.combo.currentText(), "pendente")
                    membro = self.servico.cadastrar(
                        nome=c_nome.text(),
                        cpf=c_cpf.text(),
                        data_nascimento=c_nasc.text(),
                        email=c_email.text(),
                        telefone=c_tel.text(),
                        observacoes=c_obs.toPlainText(),
                        usuario=self.usuario,
                        **extra,
                    )
                    msg = "Membro cadastrado!"
                    if getattr(membro, "parcelas_geradas", 0):
                        msg += f"\n{membro.parcelas_geradas} mensalidade(s) gerada(s)."
                    if not membro.ativo:
                        msg += "\nMembro ficou inativo por mensalidade em atraso."
                modal.accept()
                self.chk_ativos.setChecked(False)
                self._atualizar_tabela()
                QMessageBox.information(self, "Sucesso", msg)
            except (ValidacaoErro, CadastroErro, AcessoNegado) as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Salvar", salvar)
        modal.exec()

    def _atualizar_tabela(self):
        self.tabela.clear_rows()
        planos = {p.id: p.nome for p in self.servico_planos.listar()}
        for aluno in self.servico.listar(
            termo_busca=self.toolbar.termo,
            apenas_ativos=self.chk_ativos.isChecked(),
        ):
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            self.tabela.set_row(
                row,
                [
                    aluno.nome,
                    ServicoUsuarios.formatar_cpf(aluno.cpf),
                    planos.get(aluno.plano_id, "—"),
                    "Ativo" if aluno.ativo else "Inativo",
                    self.servico_pag.resumo_status_aluno(aluno.cpf),
                    ServicoUsuarios.formatar_telefone(aluno.telefone) or "—",
                ],
                row_id=aluno.cpf,
            )

    def _sel(self):
        cpf = self.tabela.selected_row_id()
        return self.servico.buscar_por_cpf(cpf) if cpf else None

    def _texto_instrutor(self, cpf):
        if not cpf:
            return "Sem instrutor"
        instr = self.servico_instr.buscar(cpf)
        if not instr:
            return "—"
        return f"{instr.nome} — {instr.especialidade}"

    def _detalhes(self):
        aluno = self._sel()
        if not aluno:
            QMessageBox.warning(self, "Atenção", "Selecione um membro.")
            return
        planos = {p.id: p.nome for p in self.servico_planos.listar()}
        modal = DetalheModal(
            self,
            aluno.nome,
            [
                ("CPF", ServicoUsuarios.formatar_cpf(aluno.cpf)),
                ("E-mail", aluno.email),
                ("Telefone", ServicoUsuarios.formatar_telefone(aluno.telefone) or "—"),
                ("Plano", planos.get(aluno.plano_id, "Sem plano")),
                ("Instrutor", self._texto_instrutor(aluno.instrutor_cpf)),
                ("Pagamento", self.servico_pag.resumo_status_aluno(aluno.cpf)),
                ("Status", "Ativo" if aluno.ativo else "Inativo"),
            ],
        )
        modal.add_botao("Editar", self._editar, secundario=True)

        def exportar_treino():
            treinos = self.servico_treinos.treinos_do_aluno(aluno.cpf)
            if not treinos:
                QMessageBox.warning(modal, "Atenção", "Nenhum treino vinculado a este membro.")
                return
            caminho, _ = QFileDialog.getSaveFileName(
                modal,
                "Salvar PDF",
                f"treino_{aluno.nome.replace(' ', '_')}.pdf",
                "PDF (*.pdf)",
            )
            if not caminho:
                return
            try:
                exportar_treinos_aluno(aluno, treinos, caminho)
                QMessageBox.information(modal, "Sucesso", f"PDF salvo:\n{caminho}")
            except Exception as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Exportar treino PDF", exportar_treino, secundario=True)
        modal.exec()

    def _editar(self):
        aluno = self._sel()
        if not aluno:
            QMessageBox.warning(self, "Atenção", "Selecione um membro.")
            return
        self._abrir_modal_novo(aluno)

    def _alternar_status(self):
        cpf = self.tabela.selected_row_id()
        if not cpf:
            QMessageBox.warning(self, "Atenção", "Selecione um membro.")
            return
        try:
            aluno = self.servico.alternar_status(cpf, usuario=self.usuario)
            self._atualizar_tabela()
            QMessageBox.information(self, "Sucesso", f"Membro {'ativado' if aluno.ativo else 'desativado'}.")
        except CadastroErro as e:
            QMessageBox.critical(self, "Erro", str(e))

    def _remover(self):
        cpf = self.tabela.selected_row_id()
        if not cpf:
            QMessageBox.warning(self, "Atenção", "Selecione um membro.")
            return
        if QMessageBox.question(self, "Confirmar", "Remover membro?") != QMessageBox.StandardButton.Yes:
            return
        try:
            self.servico.remover(cpf, usuario=self.usuario)
            self._atualizar_tabela()
            QMessageBox.information(self, "Sucesso", "Membro removido.")
        except (CadastroErro, AcessoNegado) as e:
            QMessageBox.critical(self, "Erro", str(e))
