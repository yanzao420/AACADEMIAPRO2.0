from PySide6.QtWidgets import QMessageBox, QVBoxLayout, QWidget

from core.excecoes import AcessoNegado, CadastroErro, ValidacaoErro
from core.servico_instrutores import ServicoInstrutores
from core.servico_usuarios import ServicoUsuarios
from ui.dialogs import AppModal, DetalheModal
from ui.widgets import ActionBar, Card, DataTable, FormField, MemberSearchPicker, PageToolbar


class InstrutoresPage(QWidget):
    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.servico = ServicoInstrutores()
        self.servico_usuarios = ServicoUsuarios()
        self._montar()
        self._atualizar_tabela()

    def ao_exibir(self):
        self._atualizar_tabela()

    def _montar(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 24)
        layout.setSpacing(12)

        topo = ActionBar()
        self.toolbar = PageToolbar("Buscar instrutor...", "+  Novo instrutor", self._abrir_modal_novo)
        self.toolbar.busca.input.textChanged.connect(self._atualizar_tabela)
        topo.layout.addWidget(self.toolbar, 1)
        topo.add("Vincular membro", self._abrir_modal_vincular, cta=True)
        layout.addWidget(topo)

        card = Card()
        barra = ActionBar()
        barra.add("Detalhes", self._detalhes, secondary=True)
        barra.add("Editar", self._editar, secondary=True)
        if self.usuario.pode_remover():
            barra.add("Remover", self._remover, danger=True)
        card.add_widget(barra)

        self.tabela = DataTable(
            ["nome", "cpf", "esp", "alunos"],
            ["Nome", "CPF", "Especialidade", "Alunos"],
        )
        self.tabela.bind_double_click(self._detalhes)
        card.add_widget(self.tabela)
        layout.addWidget(card, 1)

    def _abrir_modal_novo(self, instrutor=None):
        if isinstance(instrutor, bool) or not (instrutor is not None and hasattr(instrutor, "cpf")):
            instrutor = None
        modal = AppModal(
            self,
            "Editar instrutor" if instrutor else "Novo instrutor",
            "Dados do profissional da academia.",
        )
        c_nome = FormField("Nome completo")
        c_cpf = FormField("CPF")
        c_esp = FormField("Especialidade", "Ex.: Musculação")
        if instrutor:
            c_nome.set_text(instrutor.nome)
            c_cpf.set_text(ServicoUsuarios.formatar_cpf(instrutor.cpf))
            c_cpf.set_enabled(False)
            c_esp.set_text(instrutor.especialidade)
        for c in (c_nome, c_cpf, c_esp):
            modal.add_widget(c)

        def salvar():
            try:
                if instrutor:
                    self.servico.atualizar(
                        cpf=instrutor.cpf,
                        nome=c_nome.text(),
                        especialidade=c_esp.text(),
                        usuario=self.usuario,
                    )
                else:
                    self.servico.cadastrar(
                        nome=c_nome.text(),
                        cpf=c_cpf.text(),
                        especialidade=c_esp.text(),
                        usuario=self.usuario,
                    )
                modal.accept()
                self._atualizar_tabela()
                QMessageBox.information(self, "Sucesso", "Instrutor salvo!")
            except (ValidacaoErro, CadastroErro, AcessoNegado) as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Salvar", salvar)
        modal.exec()

    def _contar(self, cpf):
        return len(self.servico.alunos_vinculados(cpf))

    def _alunos_vinculados(self, cpf):
        return self.servico.alunos_vinculados(cpf)

    def _texto_alunos_vinculados(self, cpf):
        alunos = self._alunos_vinculados(cpf)
        if not alunos:
            return "Nenhum aluno vinculado."
        linhas = []
        for aluno in sorted(alunos, key=lambda a: a.nome.lower()):
            cpf_fmt = ServicoUsuarios.formatar_cpf(aluno.cpf)
            status = "Ativo" if aluno.ativo else "Inativo"
            linhas.append(f"- {aluno.nome} | {cpf_fmt} | {status}")
        return "\n".join(linhas)

    def _atualizar_tabela(self):
        self.tabela.clear_rows()
        termo = self.toolbar.termo.lower()
        for instr in self.servico.listar():
            if termo and termo not in instr.nome.lower() and termo not in instr.especialidade.lower():
                continue
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            qtd = self._contar(instr.cpf)
            self.tabela.set_row(
                row,
                [
                    instr.nome,
                    ServicoUsuarios.formatar_cpf(instr.cpf),
                    instr.especialidade,
                    f"{qtd} aluno(s)" if qtd else "Nenhum",
                ],
                row_id=instr.cpf,
            )

    def _sel(self):
        cpf = self.tabela.selected_row_id()
        return self.servico.buscar(cpf) if cpf else None

    def _detalhes(self):
        i = self._sel()
        if not i:
            QMessageBox.warning(self, "Atenção", "Selecione um instrutor.")
            return
        alunos = self._alunos_vinculados(i.cpf)
        modal = DetalheModal(
            self,
            i.nome,
            [
                ("CPF", ServicoUsuarios.formatar_cpf(i.cpf)),
                ("Especialidade", i.especialidade),
                ("Total de alunos", str(len(alunos))),
                ("Alunos vinculados", self._texto_alunos_vinculados(i.cpf), True),
            ],
            largura=520,
        )
        modal.add_botao("Vincular membro", self._abrir_modal_vincular, secundario=True)
        modal.add_botao("Editar", self._editar, secundario=True)
        modal.exec()

    def _abrir_modal_vincular(self):
        instrutor = self._sel()
        if not instrutor:
            QMessageBox.warning(self, "Atenção", "Selecione um instrutor.")
            return

        modal = AppModal(
            self,
            "Vincular membro",
            f"Busque o aluno para vincular a {instrutor.nome}.",
            largura=480,
        )
        picker = MemberSearchPicker(self.servico_usuarios)

        def vincular():
            cpf_aluno = picker.cpf
            if not cpf_aluno:
                QMessageBox.warning(modal, "Atenção", "Busque e selecione um membro.")
                return
            try:
                self.servico_usuarios.vincular_instrutor(
                    cpf_aluno,
                    instrutor.cpf,
                    usuario=self.usuario,
                )
                modal.accept()
                self._atualizar_tabela()
                QMessageBox.information(self, "Sucesso", "Membro vinculado ao instrutor!")
            except CadastroErro as e:
                QMessageBox.critical(modal, "Erro", str(e))

        modal.add_widget(picker)
        modal.add_botao("Cancelar", modal.reject, secundario=True)
        modal.add_botao("Vincular", vincular)
        modal.exec()

    def _editar(self):
        i = self._sel()
        if not i:
            QMessageBox.warning(self, "Atenção", "Selecione um instrutor.")
            return
        self._abrir_modal_novo(i)

    def _remover(self):
        cpf = self.tabela.selected_row_id()
        if not cpf:
            QMessageBox.warning(self, "Atenção", "Selecione um instrutor.")
            return
        if QMessageBox.question(self, "Confirmar", "Remover instrutor?") != QMessageBox.StandardButton.Yes:
            return
        try:
            self.servico.remover(cpf, usuario=self.usuario)
            self._atualizar_tabela()
            QMessageBox.information(self, "Sucesso", "Instrutor removido.")
        except (CadastroErro, AcessoNegado) as e:
            QMessageBox.critical(self, "Erro", str(e))
