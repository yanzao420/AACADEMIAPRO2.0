"""Interface gráfica PySide6."""
