from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from ui.pages.alunos_page import AlunosPage
from ui.pages.inicio_page import InicioPage
from ui.pages.instrutores_page import InstrutoresPage
from ui.pages.pagamentos_page import PagamentosPage
from ui.pages.planos_page import PlanosPage
from ui.pages.treinos_page import TreinosPage
from ui.widgets import btn

_ICONES = {
    "Dashboard": "⌂",
    "Membros": "👤",
    "Instrutores": "🏋",
    "Treinos": "📋",
    "Planos": "💎",
    "Pagamentos": "💳",
}


def _rotas_para(usuario):
    rotas = [
        ("Dashboard", InicioPage),
        ("Membros", AlunosPage),
        ("Instrutores", InstrutoresPage),
        ("Treinos", TreinosPage),
    ]
    if usuario.pode_gerenciar_planos():
        rotas.append(("Planos", PlanosPage))
    rotas.append(("Pagamentos", PagamentosPage))
    return rotas


class DashboardWindow(QMainWindow):

    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.ROTAS = _rotas_para(usuario)
        self._indice_membros = next(
            i for i, (nome, _) in enumerate(self.ROTAS) if nome == "Membros"
        )
        self.setWindowTitle("Academia PRO — Painel")
        self.setMinimumSize(1180, 720)
        self._nav_botoes = []
        self._montar()

    def _montar(self):
        central = QWidget()
        self.setCentralWidget(central)
        shell = QHBoxLayout(central)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        sidebar.setFixedWidth(240)
        nav = QVBoxLayout(sidebar)
        nav.setContentsMargins(14, 20, 14, 20)
        nav.setSpacing(6)

        logo = QLabel("ACADEMIA PRO")
        logo.setProperty("accent", True)
        nav.addWidget(logo)
        nav.addWidget(QLabel(f"Olá, {self.usuario.login}"))
        perfil = "Admin" if self.usuario.eh_admin else "Staff"
        lbl = QLabel(perfil)
        lbl.setProperty("muted", True)
        nav.addWidget(lbl)
        nav.addSpacing(12)
        nav.addWidget(
            btn("+  Novo membro", lambda: self._ir_para(self._indice_membros), cta=True)
        )
        nav.addSpacing(8)

        for indice, (nome, _) in enumerate(self.ROTAS):
            icone = _ICONES.get(nome, "•")
            botao = btn(
                f"  {icone}  {nome}",
                lambda checked=False, i=indice: self._ir_para(i),
                nav=True,
            )
            nav.addWidget(botao)
            self._nav_botoes.append(botao)

        nav.addStretch()
        nav.addWidget(btn("  ⎋  Sair", self._logout, nav=True))

        area = QWidget()
        area_layout = QVBoxLayout(area)
        area_layout.setContentsMargins(0, 0, 0, 0)
        area_layout.setSpacing(0)

        topbar = QFrame()
        topbar.setObjectName("topbar")
        topbar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        topbar.setFixedHeight(52)
        top_row = QHBoxLayout(topbar)
        top_row.setContentsMargins(24, 0, 24, 0)
        self.lbl_pagina = QLabel("Dashboard")
        self.lbl_pagina.setProperty("subheading", True)
        self.lbl_pagina.setAutoFillBackground(False)
        top_row.addWidget(self.lbl_pagina)
        top_row.addStretch()
        perfil = "admin" if self.usuario.eh_admin else "staff"
        lbl_usuario = QLabel(f"●  {self.usuario.login}")
        lbl_usuario.setProperty("user_role", perfil)
        lbl_usuario.style().unpolish(lbl_usuario)
        lbl_usuario.style().polish(lbl_usuario)
        top_row.addWidget(lbl_usuario)
        area_layout.addWidget(topbar)

        self.stack = QStackedWidget()
        for _, classe in self.ROTAS:
            pagina = classe(self.usuario)
            if hasattr(pagina, "vincular_dashboard"):
                pagina.vincular_dashboard(self.ir_para_rotas)
            self.stack.addWidget(pagina)
        area_layout.addWidget(self.stack, 1)

        shell.addWidget(sidebar)
        shell.addWidget(area, 1)
        self._ir_para(0)

    def ir_para_rotas(self, nome):
        for indice, (rotulo, _) in enumerate(self.ROTAS):
            if rotulo == nome:
                self._ir_para(indice)
                return

    def _ir_para(self, indice):
        self.stack.setCurrentIndex(indice)
        self.lbl_pagina.setText(self.ROTAS[indice][0])
        for i, botao in enumerate(self._nav_botoes):
            botao.setProperty("active", i == indice)
            botao.style().unpolish(botao)
            botao.style().polish(botao)
        pagina = self.stack.currentWidget()
        if hasattr(pagina, "ao_exibir"):
            pagina.ao_exibir()

    def _logout(self):
        if QMessageBox.question(self, "Sair", "Encerrar sessão?") != QMessageBox.StandardButton.Yes:
            return
        from ui.app import LoginWindow

        self.login = LoginWindow()
        self.login.show()
        self.close()
