from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from core.exportar_treino_pdf import exportar_treinos_aluno
from core.servico_instrutores import ServicoInstrutores
from core.servico_pagamentos import ServicoPagamentos
from core.servico_planos import ServicoPlanos
from core.servico_treinos import ServicoTreinos
from core.servico_usuarios import ServicoUsuarios
from models.pagamento import Pagamento
from ui.dialogs import DetalheModal
from ui.widgets import ActionBar, Card, DataTable, HeroBanner, btn


class PortalAlunoWindow(QMainWindow):
    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.servico_usuarios = ServicoUsuarios()
        self.servico_treinos = ServicoTreinos()
        self.servico_pag = ServicoPagamentos()
        self.servico_planos = ServicoPlanos()
        self.servico_instr = ServicoInstrutores()
        self.aluno = self.servico_usuarios.buscar_por_cpf(usuario.cpf_aluno)
        self._treinos = []
        self._pagamentos = []
        self.setWindowTitle("Academia PRO — Área do Aluno")
        self.setMinimumSize(900, 600)
        if not self.aluno:
            QMessageBox.critical(self, "Erro", "Cadastro não encontrado.")
            self._voltar_login()
            return
        self._montar()

    def _texto_instrutor_portal(self, cpf):
        if not cpf:
            return "Sem instrutor"
        instr = self.servico_instr.buscar(cpf)
        if not instr:
            return "—"
        return f"{instr.nome} — {instr.especialidade}"

    def _montar(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)

        topo = QFrame()
        topo.setObjectName("topbar")
        topo.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        topo_row = QHBoxLayout(topo)
        topo_row.setContentsMargins(24, 12, 24, 12)
        titulo = QLabel("ÁREA DO ALUNO")
        titulo.setProperty("subheading", True)
        topo_row.addWidget(titulo)
        topo_row.addStretch()
        lbl_aluno = QLabel(f"●  {self.aluno.nome.split()[0]}")
        lbl_aluno.setProperty("user_role", "aluno")
        topo_row.addWidget(lbl_aluno)
        topo_row.addWidget(btn("Sair", self._logout, secondary=True))
        layout.addWidget(topo)

        corpo = QWidget()
        corpo_layout = QVBoxLayout(corpo)
        corpo_layout.setContentsMargins(32, 24, 32, 24)
        tabs = QTabWidget()
        tabs.addTab(self._aba_info(), "MINHAS INFORMAÇÕES")
        tabs.addTab(self._aba_treinos(), "MEUS TREINOS")
        tabs.addTab(self._aba_fin(), "FINANCEIRO")
        corpo_layout.addWidget(tabs)
        layout.addWidget(corpo, 1)

    def _campos_info_aluno(self):
        plano = "—"
        if self.aluno.plano_id:
            p = self.servico_planos.buscar(self.aluno.plano_id)
            if p:
                plano = f"{p.nome} — {ServicoPlanos.formatar_valor(p.valor)}"
        return [
            ("CPF", ServicoUsuarios.formatar_cpf(self.aluno.cpf)),
            ("Nascimento", self.aluno.data_nascimento),
            ("E-mail", self.aluno.email),
            ("Telefone", ServicoUsuarios.formatar_telefone(self.aluno.telefone) or "—"),
            ("Plano", plano),
            ("Instrutor", self._texto_instrutor_portal(self.aluno.instrutor_cpf)),
            ("Status", "Ativo" if self.aluno.ativo else "Inativo"),
            ("Observações", self.aluno.observacoes or "—"),
        ]

    def _aba_info(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.addWidget(
            HeroBanner("Suas informações", "Dados cadastrais e plano contratado.")
        )
        card = Card()
        for rotulo, valor in self._campos_info_aluno():
            linha = QWidget()
            row = QVBoxLayout(linha)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(4)
            lbl = QLabel(rotulo)
            lbl.setProperty("field_label", True)
            val = QLabel(str(valor))
            val.setWordWrap(True)
            row.addWidget(lbl)
            row.addWidget(val)
            card.add_widget(linha)
        layout.addWidget(card)
        layout.addStretch()
        return w

    def _aba_treinos(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(8, 8, 8, 8)
        card = Card()
        barra = ActionBar()
        barra.add("Exportar PDF", self._exportar_pdf, cta=True)
        barra.add("Ver ficha", self._modal_treinos, secondary=True)
        card.add_widget(barra)
        self._treinos = self.servico_treinos.treinos_do_aluno(self.aluno.cpf)
        if not self._treinos:
            card.add_widget(QLabel("Nenhum treino vinculado."))
        else:
            for t in self._treinos:
                bloco = QLabel(
                    f"<b style='color:#22d3ee'>{t.nome}</b> — {t.duracao_minutos} min<br>"
                    f"<span style='color:#a1a1aa'>{t.descricao or 'Sem descrição.'}</span>"
                )
                bloco.setWordWrap(True)
                card.add_widget(bloco)
        layout.addWidget(card, 1)
        return w

    def _modal_treinos(self):
        if not self._treinos:
            QMessageBox.information(self, "Treinos", "Nenhum treino vinculado.")
            return
        campos = []
        for t in self._treinos:
            campos.append((t.nome, f"{t.duracao_minutos} min — {t.descricao or 'Sem descrição'}"))
        modal = DetalheModal(self, "Minha ficha de treinos", campos)
        modal.add_botao("Exportar PDF", self._exportar_pdf, secundario=True)
        modal.exec()

    def _aba_fin(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(8, 8, 8, 8)
        card = Card()
        resumo = self.servico_pag.resumo_status_aluno(self.aluno.cpf)
        lbl = QLabel(f"Situação: {resumo}")
        lbl.setProperty("accent", True)
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card.add_widget(lbl)
        self.tabela_fin = DataTable(
            ["venc", "valor", "status", "desc"],
            ["Vencimento", "Valor", "Status", "Descrição"],
        )
        self._pagamentos = self.servico_pag.listar_por_aluno(self.aluno.cpf)
        rotulos = {
            Pagamento.STATUS_PAGO: "Pago",
            Pagamento.STATUS_PENDENTE: "Pendente",
            Pagamento.STATUS_ATRASADO: "Atrasado",
        }
        for pag in self._pagamentos:
            row = self.tabela_fin.rowCount()
            self.tabela_fin.insertRow(row)
            self.tabela_fin.set_row(
                row,
                [
                    pag.vencimento,
                    f"R$ {pag.valor:.2f}".replace(".", ","),
                    rotulos.get(pag.status, pag.status),
                    pag.descricao or "—",
                ],
                row_id=pag.id,
            )
        self.tabela_fin.bind_double_click(self._modal_pagamento)
        card.add_widget(self.tabela_fin)
        layout.addWidget(card, 1)
        return w

    def _modal_pagamento(self):
        pid = self.tabela_fin.selected_row_id()
        pag = next((p for p in self._pagamentos if p.id == pid), None)
        if not pag:
            return
        rotulos = {
            Pagamento.STATUS_PAGO: "Pago",
            Pagamento.STATUS_PENDENTE: "Pendente",
            Pagamento.STATUS_ATRASADO: "Atrasado",
        }
        DetalheModal(
            self,
            "Detalhe da mensalidade",
            [
                ("Vencimento", pag.vencimento),
                ("Valor", f"R$ {pag.valor:.2f}".replace(".", ",")),
                ("Status", rotulos.get(pag.status, pag.status)),
                ("Descrição", pag.descricao or "—"),
            ],
        ).exec()

    def _exportar_pdf(self):
        treinos = self.servico_treinos.treinos_do_aluno(self.aluno.cpf)
        if not treinos:
            QMessageBox.warning(self, "Atenção", "Nenhum treino para exportar.")
            return
        caminho, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar PDF",
            f"treino_{self.aluno.nome.replace(' ', '_')}.pdf",
            "PDF (*.pdf)",
        )
        if not caminho:
            return
        try:
            exportar_treinos_aluno(self.aluno, treinos, caminho)
            QMessageBox.information(self, "Sucesso", f"PDF salvo:\n{caminho}")
        except Exception as e:
            QMessageBox.critical(self, "Erro", str(e))

    def _logout(self):
        if QMessageBox.question(self, "Sair", "Deseja sair?") == QMessageBox.StandardButton.Yes:
            self._voltar_login()

    def _voltar_login(self):
        from ui.app import LoginWindow

        self.login = LoginWindow()
        self.login.show()
        self.close()
