"""Tema visual — dark moderno com acento ciano (inspirado em dashboards fitness)."""

# Paleta (diferente do modelo lime-green)
BG_APP = "#0c0c0e"
BG_SIDEBAR = "#111114"
BG_CARD = "#18181b"
BG_INPUT = "#27272a"
BG_HOVER = "#3f3f46"
ACCENT = "#06b6d4"
ACCENT_HOVER = "#22d3ee"
ACCENT_DARK = "#0891b2"
TEXTO = "#fafafa"
TEXTO_SUAVE = "#e4e4e7"
TEXTO_MUTED = "#a1a1aa"
BORDA = "#3f3f46"
SUCESSO = "#10b981"
ERRO = "#f43f5e"
AVISO = "#f59e0b"

STYLESHEET = f"""
QWidget {{
    background-color: {BG_APP};
    color: {TEXTO};
    font-family: "Segoe UI", sans-serif;
    font-size: 10pt;
}}

QLabel {{
    background: transparent;
}}

QMainWindow, QDialog {{
    background-color: {BG_APP};
}}

QDialog#modal {{
    background-color: {BG_CARD};
    border: 1px solid {BORDA};
    border-radius: 14px;
}}

QScrollArea {{
    border: none;
    background: transparent;
}}

QScrollBar:vertical {{
    background: {BG_SIDEBAR};
    width: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:vertical {{
    background: {BG_HOVER};
    border-radius: 4px;
    min-height: 24px;
}}

QLineEdit, QComboBox, QTextEdit, QPlainTextEdit, QSpinBox {{
    background-color: {BG_INPUT};
    border: 1px solid {BORDA};
    border-radius: 10px;
    padding: 8px 12px;
    min-height: 20px;
    max-height: 42px;
    color: {TEXTO};
    font-size: 10pt;
    selection-background-color: {ACCENT_DARK};
}}
QTextEdit, QPlainTextEdit {{
    max-height: 120px;
    padding: 10px 12px;
}}
QLineEdit:focus, QComboBox:focus, QTextEdit:focus {{
    border: 1px solid {ACCENT};
}}
QComboBox::drop-down {{
    border: none;
    width: 24px;
}}
QComboBox QAbstractItemView {{
    background-color: {BG_CARD};
    border: 1px solid {BORDA};
    selection-background-color: {ACCENT_DARK};
    color: {TEXTO};
    padding: 4px;
}}

QPushButton {{
    background-color: {ACCENT};
    color: #0c0c0e;
    border: none;
    border-radius: 10px;
    padding: 9px 18px;
    font-weight: 700;
    font-size: 10pt;
    min-height: 18px;
}}
QPushButton:hover {{
    background-color: {ACCENT_HOVER};
}}
QPushButton:pressed {{
    background-color: {ACCENT_DARK};
    color: white;
}}
QPushButton:disabled {{
    background-color: {BG_INPUT};
    color: {TEXTO_MUTED};
}}
QPushButton[secondary="true"] {{
    background-color: {BG_INPUT};
    color: {TEXTO};
    border: 1px solid {BORDA};
}}
QPushButton[secondary="true"]:hover {{
    background-color: {BG_HOVER};
    border-color: {ACCENT};
}}
QPushButton[danger="true"] {{
    background-color: {ERRO};
    color: white;
}}
QPushButton[ghost="true"] {{
    background-color: transparent;
    color: {TEXTO_MUTED};
    border: none;
}}
QPushButton[nav="true"] {{
    background-color: transparent;
    color: {TEXTO_MUTED};
    text-align: left;
    padding: 11px 14px;
    border-radius: 10px;
    font-weight: 500;
}}
QPushButton[nav="true"]:hover {{
    background-color: {BG_INPUT};
    color: {TEXTO};
}}
QPushButton[nav="true"][active="true"] {{
    background-color: {BG_INPUT};
    color: {ACCENT_HOVER};
    border-left: 3px solid {ACCENT};
}}
QPushButton[cta="true"] {{
    background-color: {ACCENT};
    color: #0c0c0e;
    font-weight: 800;
    padding: 12px;
}}

QTableWidget {{
    background-color: {BG_APP};
    alternate-background-color: #141416;
    gridline-color: #2a2a2e;
    border: 1px solid #2a2a2e;
    border-radius: 12px;
    selection-background-color: {ACCENT_DARK};
    selection-color: white;
}}
QTableWidget::item {{
    padding: 10px 8px;
    text-align: center;
}}
QHeaderView::section {{
    background-color: {BG_APP};
    color: {TEXTO_SUAVE};
    padding: 10px 8px;
    border: none;
    border-bottom: 1px solid #2a2a2e;
    font-weight: 600;
    font-size: 9pt;
    text-transform: uppercase;
    text-align: center;
}}
QHeaderView::section:hover {{
    background-color: {BG_INPUT};
    color: {ACCENT_HOVER};
}}

QTabWidget::pane {{
    border: 1px solid {BORDA};
    border-radius: 12px;
    background: {BG_CARD};
    top: -1px;
}}
QTabBar::tab {{
    background: {BG_INPUT};
    color: {TEXTO_MUTED};
    padding: 10px 20px;
    margin-right: 4px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
}}
QTabBar::tab:selected {{
    background: {BG_CARD};
    color: {ACCENT_HOVER};
    border-bottom: 2px solid {ACCENT};
}}

QFrame#card {{
    background-color: {BG_CARD};
    border: 1px solid {BORDA};
    border-radius: 14px;
}}
QFrame#surface, QFrame#stat_card {{
    background-color: {BG_APP};
    border: 1px solid #2a2a2e;
    border-radius: 14px;
}}
QFrame#hero {{
    background-color: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #164e63, stop:1 #0c0c0e);
    border: 1px solid {BORDA};
    border-radius: 16px;
}}
QFrame#sidebar {{
    background-color: {BG_APP};
    border-right: 1px solid #2a2a2e;
}}
QFrame#topbar {{
    background-color: {BG_APP};
    border-bottom: 1px solid #2a2a2e;
}}

QLabel[heading="true"] {{
    font-size: 20pt;
    font-weight: 800;
    color: {TEXTO};
}}
QLabel[subheading="true"] {{
    font-size: 13pt;
    font-weight: 700;
    color: {TEXTO};
}}
QLabel[field_label="true"] {{
    color: {TEXTO_MUTED};
    font-size: 9pt;
    font-weight: 500;
    padding-bottom: 2px;
}}
QLabel[muted="true"] {{
    color: {TEXTO_MUTED};
    font-size: 9pt;
}}
QLabel[accent="true"] {{
    color: {ACCENT_HOVER};
    font-weight: 700;
}}
QLabel[user_role="admin"] {{
    color: {ACCENT_HOVER};
    background-color: rgba(6, 182, 212, 0.12);
    border: 1px solid {ACCENT_DARK};
    border-radius: 16px;
    padding: 6px 14px;
    font-weight: 600;
    font-size: 10pt;
}}
QLabel[user_role="staff"] {{
    color: #c4b5fd;
    background-color: rgba(139, 92, 246, 0.12);
    border: 1px solid #7c3aed;
    border-radius: 16px;
    padding: 6px 14px;
    font-weight: 600;
    font-size: 10pt;
}}
QLabel[user_role="aluno"] {{
    color: #34d399;
    background-color: rgba(16, 185, 129, 0.12);
    border: 1px solid #059669;
    border-radius: 16px;
    padding: 6px 14px;
    font-weight: 600;
    font-size: 10pt;
}}
QLabel[stat_title="true"] {{
    color: {TEXTO_SUAVE};
    font-size: 11pt;
    font-weight: 500;
}}
QLabel[stat_value="true"] {{
    font-size: 16pt;
    font-weight: 700;
    color: {TEXTO};
}}

QCheckBox {{
    spacing: 8px;
    color: {TEXTO};
}}
QCheckBox::indicator {{
    width: 18px;
    height: 18px;
    border-radius: 5px;
    border: 1px solid {BORDA};
    background: {BG_INPUT};
}}
QCheckBox::indicator:checked {{
    background: {ACCENT};
    border-color: {ACCENT};
}}

QListWidget {{
    background-color: {BG_INPUT};
    border: 1px solid {BORDA};
    border-radius: 10px;
    padding: 6px;
}}
QListWidget::item {{
    padding: 10px;
    border-radius: 8px;
    text-align: center;
}}
QListWidget::item:selected {{
    background-color: {ACCENT_DARK};
}}
"""
