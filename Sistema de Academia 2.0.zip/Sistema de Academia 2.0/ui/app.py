import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication, QLabel, QMainWindow, QMessageBox, QVBoxLayout, QWidget

from core.autenticacao import Autenticacao
from core.excecoes import AcessoNegado
from ui.dashboard import DashboardWindow
from ui.portal import PortalAlunoWindow
from ui.theme import STYLESHEET
from ui.widgets import Card, FormField, btn


class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Academia PRO — Login")
        self.setMinimumSize(480, 520)
        self.auth = Autenticacao()
        self._montar()

    def _montar(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setAlignment(__import__("PySide6.QtCore", fromlist=["Qt"]).Qt.AlignmentFlag.AlignCenter)

        card = Card(integrado=True)
        card.setMaximumWidth(400)
        card._layout.setContentsMargins(28, 28, 28, 28)

        titulo = QLabel("ACADEMIA PRO")
        titulo.setProperty("heading", True)
        card.add_widget(titulo)
        sub = QLabel("Entre com sua conta")
        sub.setProperty("stat_title", True)
        card.add_widget(sub)

        self.campo_usuario = FormField("Usuário", "admin ou CPF do aluno")
        card.add_widget(self.campo_usuario)
        self.campo_senha = FormField("Senha", "••••••", password=True)
        card.add_widget(self.campo_senha)

        card.add_widget(btn("Entrar", self._entrar, cta=True))

        ajuda = QLabel(
            "Staff: admin/123  •  funcionario/123\n"
            "Aluno: CPF + data de nascimento"
        )
        ajuda.setProperty("muted", True)
        ajuda.setWordWrap(True)
        card.add_widget(ajuda)

        layout.addWidget(card)
        self.campo_senha.input.returnPressed.connect(self._entrar)

    def _entrar(self):
        try:
            usuario = self.auth.login(
                self.campo_usuario.text(),
                self.campo_senha.text(),
            )
            if usuario.eh_aluno:
                self._abrir(PortalAlunoWindow(usuario))
            else:
                self._abrir(DashboardWindow(usuario))
        except AcessoNegado as erro:
            QMessageBox.critical(self, "Acesso negado", str(erro))

    def _abrir(self, janela):
        janela.show()
        self.close()


class App:
    def __init__(self):
        _raiz = Path(__file__).resolve().parent.parent
        if str(_raiz) not in sys.path:
            sys.path.insert(0, str(_raiz))

        self.qt = QApplication(sys.argv)
        self.qt.setStyle("Fusion")
        self.qt.setStyleSheet(STYLESHEET)
        self.login = LoginWindow()
        self.login.show()
        sys.exit(self.qt.exec())
