class Usuario:

    def __init__(self, login, senha, nivel, cpf_aluno=None):
        self._login = login
        self._senha = senha
        self._nivel = nivel
        self._cpf_aluno = cpf_aluno

    @property
    def login(self):
        return self._login

    @property
    def nivel(self):
        return self._nivel

    @property
    def cpf_aluno(self):
        return self._cpf_aluno

    @property
    def eh_admin(self):
        return self._nivel == "admin"

    @property
    def eh_aluno(self):
        return self._nivel == "aluno"

    @property
    def eh_funcionario(self):
        return self._nivel == "funcionario"

    def verificar_senha(self, senha):
        return self._senha == senha

    def pode_cadastrar(self):
        return not self.eh_aluno

    def pode_editar(self):
        return not self.eh_aluno

    def pode_remover(self):
        return self.eh_admin

    def pode_desativar(self):
        return not self.eh_aluno

    def pode_gerenciar_planos(self):
        return self.eh_admin

    def pode_gerenciar_pagamentos(self):
        return not self.eh_aluno

    def pode_exportar(self):
        return not self.eh_aluno
