class Treino:

    def __init__(self, id_treino, nome, duracao_minutos=60, descricao=""):
        self.id = id_treino
        self.nome = nome
        self.duracao_minutos = int(duracao_minutos)
        self.descricao = (descricao or "").strip()

    def to_dict(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "duracao_minutos": self.duracao_minutos,
            "descricao": self.descricao,
        }

    @classmethod
    def from_dict(cls, dados):
        return cls(
            id_treino=dados["id"],
            nome=dados["nome"],
            duracao_minutos=dados.get("duracao_minutos", 60),
            descricao=dados.get("descricao", ""),
        )
