"""Entidades de domínio da academia."""
