class Plano:

    def __init__(self, id_plano, nome, valor, duracao_meses):
        self.id = id_plano
        self.nome = nome
        self.valor = float(valor)
        self.duracao_meses = int(duracao_meses)

    def apresentar(self):
        return f"{self.nome} — R$ {self.valor:.2f} ({self.duracao_meses} meses)"

    def to_dict(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "valor": self.valor,
            "duracao_meses": self.duracao_meses,
        }

    @classmethod
    def from_dict(cls, dados):
        return cls(
            id_plano=dados["id"],
            nome=dados["nome"],
            valor=dados["valor"],
            duracao_meses=dados["duracao_meses"],
        )
