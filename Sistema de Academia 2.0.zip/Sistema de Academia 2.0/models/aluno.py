from models.pessoa import Pessoa
from models.treino import Treino


class Aluno(Pessoa):

    def __init__(
        self,
        nome_completo,
        cpf,
        data_nascimento,
        email,
        telefone="",
        observacoes="",
        plano_id=None,
        instrutor_cpf=None,
        treinos=None,
        ativo=True,
    ):
        super().__init__(nome_completo, cpf)
        self.data_nascimento = data_nascimento
        self.email = email
        self.telefone = telefone
        self.observacoes = observacoes
        self.plano_id = plano_id
        self.instrutor_cpf = instrutor_cpf or None
        self._treinos = treinos or []
        self.ativo = ativo

    @property
    def nome_completo(self):
        return self.nome

    @property
    def treinos(self):
        return list(self._treinos)

    def definir_plano(self, plano):
        self.plano_id = plano.id if plano else None

    def adicionar_treino(self, treino):
        if isinstance(treino, Treino):
            self._treinos.append(treino.to_dict())
        else:
            self._treinos.append(treino)

    def apresentar(self):
        status = "Ativo" if self.ativo else "Inativo"
        plano = f"Plano: {self.plano_id}" if self.plano_id else "Sem plano"
        return (
            f"Aluno: {self.nome} | {status} | {plano} | "
            f"CPF: {self.cpf} | {self.email} | Tel: {self.telefone or '—'}"
        )

    def to_dict(self):
        return {
            "nome_completo": self.nome,
            "cpf": self.cpf,
            "data_nascimento": self.data_nascimento,
            "email": self.email,
            "telefone": self.telefone,
            "observacoes": self.observacoes,
            "plano_id": self.plano_id,
            "instrutor_cpf": self.instrutor_cpf,
            "treinos": self._treinos,
            "ativo": self.ativo,
        }

    @classmethod
    def from_dict(cls, dados):
        plano_id = dados.get("plano_id")
        if plano_id is None and dados.get("plano"):
            plano_id = dados.get("plano")

        return cls(
            nome_completo=dados["nome_completo"],
            cpf=dados["cpf"],
            data_nascimento=dados["data_nascimento"],
            email=dados["email"],
            telefone=dados.get("telefone", ""),
            observacoes=dados.get("observacoes", ""),
            plano_id=plano_id,
            instrutor_cpf=dados.get("instrutor_cpf"),
            treinos=dados.get("treinos", []),
            ativo=dados.get("ativo", True),
        )

    def __str__(self):
        return self.apresentar()
