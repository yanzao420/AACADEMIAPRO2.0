from datetime import datetime


class Pagamento:

    STATUS_PENDENTE = "pendente"
    STATUS_PAGO = "pago"
    STATUS_ATRASADO = "atrasado"

    def __init__(
        self,
        id_pagamento,
        aluno_cpf,
        valor,
        vencimento,
        status=STATUS_PENDENTE,
        plano_id=None,
        descricao="",
    ):
        self.id = id_pagamento
        self.aluno_cpf = aluno_cpf
        self.valor = float(valor)
        self.vencimento = vencimento
        self.status = status
        self.plano_id = plano_id
        self.descricao = descricao

    def atualizar_status_por_vencimento(self):
        if self.status == self.STATUS_PAGO:
            return
        try:
            venc = datetime.strptime(self.vencimento, "%d/%m/%Y").date()
        except ValueError:
            return
        if venc < datetime.now().date():
            self.status = self.STATUS_ATRASADO

    def marcar_pago(self):
        self.status = self.STATUS_PAGO

    def to_dict(self):
        return {
            "id": self.id,
            "aluno_cpf": self.aluno_cpf,
            "valor": self.valor,
            "vencimento": self.vencimento,
            "status": self.status,
            "plano_id": self.plano_id,
            "descricao": self.descricao,
        }

    @classmethod
    def from_dict(cls, dados):
        pagamento = cls(
            id_pagamento=dados["id"],
            aluno_cpf=dados["aluno_cpf"],
            valor=dados["valor"],
            vencimento=dados["vencimento"],
            status=dados.get("status", cls.STATUS_PENDENTE),
            plano_id=dados.get("plano_id"),
            descricao=dados.get("descricao", ""),
        )
        pagamento.atualizar_status_por_vencimento()
        return pagamento
