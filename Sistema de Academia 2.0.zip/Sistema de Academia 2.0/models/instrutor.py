from models.pessoa import Pessoa


class Instrutor(Pessoa):

    def __init__(self, nome, cpf, especialidade):
        super().__init__(nome, cpf)
        self.especialidade = especialidade

    def apresentar(self):
        return f"Instrutor: {self.nome} | {self.especialidade} | CPF: {self.cpf}"

    def to_dict(self):
        return {
            "nome": self.nome,
            "cpf": self.cpf,
            "especialidade": self.especialidade,
        }

    @classmethod
    def from_dict(cls, dados):
        return cls(
            nome=dados["nome"],
            cpf=dados["cpf"],
            especialidade=dados["especialidade"],
        )
