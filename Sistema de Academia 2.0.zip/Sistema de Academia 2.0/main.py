import sys
from pathlib import Path

# Garante imports de `core` e `ui` ao iniciar pelo main.py
_RAIZ = Path(__file__).resolve().parent
if str(_RAIZ) not in sys.path:
    sys.path.insert(0, str(_RAIZ))

from ui.app import App

if __name__ == "__main__":
    App()
