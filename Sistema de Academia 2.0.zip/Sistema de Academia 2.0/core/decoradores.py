import functools
from datetime import datetime
from pathlib import Path

from core.excecoes import AcessoNegado

LOG_DIR = Path(__file__).resolve().parent.parent / "database"
LOG_ARQUIVO = LOG_DIR / "operacoes.log"


def registrar_operacao(nome_operacao=None):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            resultado = func(*args, **kwargs)
            operacao = nome_operacao or func.__name__
            _gravar_log(f"[{datetime.now():%d/%m/%Y %H:%M:%S}] {operacao} — OK")
            return resultado

        return wrapper

    return decorator


def requer_permissao(metodo_permissao):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            usuario = kwargs.get("usuario")
            if usuario is None and args:
                ultimo = args[-1]
                if hasattr(ultimo, "login"):
                    usuario = ultimo

            if usuario is None:
                raise AcessoNegado("Usuário não autenticado.")

            permissao = getattr(usuario, metodo_permissao, None)
            if not callable(permissao) or not permissao():
                raise AcessoNegado("Você não tem permissão para esta ação.")

            return func(self, *args, **kwargs)

        return wrapper

    return decorator


def _gravar_log(linha):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_ARQUIVO, "a", encoding="utf-8") as arquivo:
        arquivo.write(linha + "\n")
