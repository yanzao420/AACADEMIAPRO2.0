from core.decoradores import registrar_operacao, requer_permissao
from core.excecoes import CadastroErro
from core.repositorio import RepositorioAcademia
from core.validacao import validar_duracao_meses, validar_nome_plano, validar_valor_monetario
from models.plano import Plano


class ServicoPlanos:

    def __init__(self, repositorio=None):
        self.repositorio = repositorio or RepositorioAcademia()

    def listar(self):
        return self.repositorio.listar_planos()

    def buscar(self, id_plano):
        return self.repositorio.buscar_plano_por_id(id_plano)

    @requer_permissao("pode_gerenciar_planos")
    @registrar_operacao("cadastrar_plano")
    def cadastrar(self, nome, valor, duracao_meses, usuario=None):
        plano = Plano(
            id_plano=self.repositorio._novo_id("plano"),
            nome=validar_nome_plano(nome),
            valor=validar_valor_monetario(valor),
            duracao_meses=validar_duracao_meses(duracao_meses),
        )
        self.repositorio.adicionar_plano(plano)
        return plano

    @requer_permissao("pode_gerenciar_planos")
    @registrar_operacao("atualizar_plano")
    def atualizar(self, id_plano, nome, valor, duracao_meses, usuario=None):
        existente = self.repositorio.buscar_plano_por_id(id_plano)
        if not existente:
            raise CadastroErro("Plano não encontrado.")

        plano = Plano(
            id_plano=id_plano,
            nome=validar_nome_plano(nome),
            valor=validar_valor_monetario(valor),
            duracao_meses=validar_duracao_meses(duracao_meses),
        )
        self.repositorio.atualizar_plano(plano)
        return plano

    @requer_permissao("pode_gerenciar_planos")
    @registrar_operacao("remover_plano")
    def remover(self, id_plano, usuario=None):
        if not self.repositorio.buscar_plano_por_id(id_plano):
            raise CadastroErro("Plano não encontrado.")
        self._limpar_vinculos_plano(id_plano)
        self.repositorio.remover_plano(id_plano)

    def _limpar_vinculos_plano(self, id_plano):
        from core.servico_pagamentos import ServicoPagamentos

        for aluno in self.repositorio.listar_alunos():
            if aluno.plano_id == id_plano:
                aluno.plano_id = None
                self.repositorio.atualizar_aluno(aluno)
        ServicoPagamentos(self.repositorio).remover_por_plano(id_plano)

    @staticmethod
    def formatar_valor(valor):
        return f"R$ {float(valor):.2f}".replace(".", ",")
