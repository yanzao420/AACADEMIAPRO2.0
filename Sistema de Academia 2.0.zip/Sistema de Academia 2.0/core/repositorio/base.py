import sqlite3
import uuid
from pathlib import Path

from core.catalogo_treinos import CATALOGO_TREINOS_PADRAO
from core.migracao_dados import migrar_json_para_sqlite

BASE_DIR = Path(__file__).resolve().parent.parent.parent
ARQUIVO_DB = BASE_DIR / "database" / "academia.db"
_INSTANCIA_PADRAO = None

_SCHEMA = """
CREATE TABLE IF NOT EXISTS alunos (
    cpf TEXT PRIMARY KEY,
    nome_completo TEXT NOT NULL,
    data_nascimento TEXT,
    email TEXT,
    telefone TEXT,
    observacoes TEXT,
    plano_id TEXT,
    instrutor_cpf TEXT,
    treinos_json TEXT DEFAULT '[]',
    ativo INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS planos (
    id TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    valor REAL NOT NULL,
    duracao_meses INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS pagamentos (
    id TEXT PRIMARY KEY,
    aluno_cpf TEXT NOT NULL,
    valor REAL NOT NULL,
    vencimento TEXT NOT NULL,
    status TEXT NOT NULL,
    plano_id TEXT,
    descricao TEXT
);

CREATE TABLE IF NOT EXISTS instrutores (
    cpf TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    especialidade TEXT
);

CREATE TABLE IF NOT EXISTS catalogo_treinos (
    id TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    duracao_minutos INTEGER,
    descricao TEXT
);
"""


class RepositorioBase:

    def __init__(self, caminho=None):
        global _INSTANCIA_PADRAO

        self.caminho = Path(caminho or ARQUIVO_DB)
        destino = self.caminho.resolve()
        padrao = ARQUIVO_DB.resolve()

        if destino == padrao and _INSTANCIA_PADRAO is not None:
            self._usa_compartilhado = True
            self._conexao = _INSTANCIA_PADRAO._conexao
            self.caminho = _INSTANCIA_PADRAO.caminho
            return

        self._usa_compartilhado = destino == padrao
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        self._conexao = sqlite3.connect(str(self.caminho), check_same_thread=False)
        self._conexao.row_factory = sqlite3.Row
        self._conexao.execute("PRAGMA foreign_keys = ON")
        self._conexao.execute("PRAGMA journal_mode = WAL")
        self._garantir_banco()

        if self._usa_compartilhado:
            _INSTANCIA_PADRAO = self

    def _garantir_banco(self):
        self._conexao.executescript(_SCHEMA)
        if self.caminho.resolve() == ARQUIVO_DB.resolve():
            migrar_json_para_sqlite(self._conexao)
        self._criar_instrutores_padrao()
        self._criar_catalogo_treinos()
        self._normalizar_vinculos_instrutor()
        self._conexao.commit()

    def close(self):
        if getattr(self, "_usa_compartilhado", False):
            return
        self._conexao.close()

    def _criar_catalogo_treinos(self):
        cur = self._conexao.cursor()
        cur.execute("SELECT COUNT(*) FROM catalogo_treinos")
        if cur.fetchone()[0] == 0:
            for item in CATALOGO_TREINOS_PADRAO:
                cur.execute(
                    """
                    INSERT INTO catalogo_treinos (id, nome, duracao_minutos, descricao)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        item["id"],
                        item["nome"],
                        item.get("duracao_minutos", 60),
                        item.get("descricao", ""),
                    ),
                )
            self._conexao.commit()

    def _criar_instrutores_padrao(self):
        cur = self._conexao.cursor()
        cur.execute("SELECT COUNT(*) FROM instrutores")
        if cur.fetchone()[0] == 0:
            cur.execute(
                """
                INSERT INTO instrutores (cpf, nome, especialidade)
                VALUES (?, ?, ?)
                """,
                ("39053344705", "Carlos Pereira", "Musculação"),
            )
            self._conexao.commit()

    @staticmethod
    def _cpf_limpo(cpf):
        return "".join(filter(str.isdigit, cpf or ""))

    def _novo_id(self, prefixo):
        return f"{prefixo}_{uuid.uuid4().hex[:8]}"

    def _normalizar_vinculos_instrutor(self):
        cur = self._conexao.cursor()
        cur.execute("SELECT cpf, instrutor_cpf FROM alunos WHERE instrutor_cpf IS NOT NULL")
        for row in cur.fetchall():
            limpo = self._cpf_limpo(row["instrutor_cpf"])
            if not limpo:
                cur.execute("UPDATE alunos SET instrutor_cpf = NULL WHERE cpf = ?", (row["cpf"],))
            elif limpo != row["instrutor_cpf"]:
                instrutor = self.buscar_instrutor_por_cpf(limpo)
                cur.execute(
                    "UPDATE alunos SET instrutor_cpf = ? WHERE cpf = ?",
                    (limpo if instrutor else None, row["cpf"]),
                )
            else:
                instrutor = self.buscar_instrutor_por_cpf(limpo)
                if not instrutor:
                    cur.execute("UPDATE alunos SET instrutor_cpf = NULL WHERE cpf = ?", (row["cpf"],))
