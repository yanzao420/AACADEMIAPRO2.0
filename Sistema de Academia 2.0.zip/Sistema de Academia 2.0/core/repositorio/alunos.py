import json

from models.aluno import Aluno


class RepositorioAlunosMixin:

    def _row_aluno(self, row):
        treinos = json.loads(row["treinos_json"] or "[]")
        instrutor_cpf = row["instrutor_cpf"]
        if instrutor_cpf:
            instrutor_cpf = self._cpf_limpo(instrutor_cpf) or None
        return Aluno.from_dict(
            {
                "nome_completo": row["nome_completo"],
                "cpf": row["cpf"],
                "data_nascimento": row["data_nascimento"],
                "email": row["email"],
                "telefone": row["telefone"] or "",
                "observacoes": row["observacoes"] or "",
                "plano_id": row["plano_id"],
                "instrutor_cpf": instrutor_cpf,
                "treinos": treinos,
                "ativo": bool(row["ativo"]),
            }
        )

    def listar_alunos(self, apenas_ativos=False):
        cur = self._conexao.cursor()
        if apenas_ativos:
            cur.execute("SELECT * FROM alunos WHERE ativo = 1 ORDER BY nome_completo")
        else:
            cur.execute("SELECT * FROM alunos ORDER BY nome_completo")
        return [self._row_aluno(row) for row in cur.fetchall()]

    def listar_alunos_por_instrutor(self, cpf_instrutor):
        cpf_limpo = self._cpf_limpo(cpf_instrutor)
        if not cpf_limpo:
            return []
        cur = self._conexao.cursor()
        cur.execute(
            """
            SELECT * FROM alunos
            WHERE REPLACE(REPLACE(REPLACE(COALESCE(instrutor_cpf, ''), '.', ''), '-', ''), ' ', '') = ?
            ORDER BY nome_completo
            """,
            (cpf_limpo,),
        )
        return [self._row_aluno(row) for row in cur.fetchall()]

    def buscar_aluno_por_cpf(self, cpf):
        cpf_limpo = self._cpf_limpo(cpf)
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM alunos WHERE cpf = ?", (cpf_limpo,))
        row = cur.fetchone()
        return self._row_aluno(row) if row else None

    def adicionar_aluno(self, aluno):
        from core.excecoes import CadastroErro

        if self.buscar_aluno_por_cpf(aluno.cpf):
            raise CadastroErro("Já existe um usuário cadastrado com este CPF.")

        dados = aluno.to_dict()
        self._conexao.execute(
            """
            INSERT INTO alunos (
                cpf, nome_completo, data_nascimento, email, telefone,
                observacoes, plano_id, instrutor_cpf, treinos_json, ativo
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                dados["cpf"],
                dados["nome_completo"],
                dados["data_nascimento"],
                dados["email"],
                dados["telefone"],
                dados["observacoes"],
                dados["plano_id"],
                dados["instrutor_cpf"],
                json.dumps(dados.get("treinos", []), ensure_ascii=False),
                1 if dados.get("ativo", True) else 0,
            ),
        )
        self._conexao.commit()

    def atualizar_aluno(self, aluno):
        from core.excecoes import CadastroErro

        dados = aluno.to_dict()
        cur = self._conexao.cursor()
        cur.execute(
            """
            UPDATE alunos SET
                nome_completo = ?, data_nascimento = ?, email = ?, telefone = ?,
                observacoes = ?, plano_id = ?, instrutor_cpf = ?,
                treinos_json = ?, ativo = ?
            WHERE cpf = ?
            """,
            (
                dados["nome_completo"],
                dados["data_nascimento"],
                dados["email"],
                dados["telefone"],
                dados["observacoes"],
                dados["plano_id"],
                dados["instrutor_cpf"],
                json.dumps(dados.get("treinos", []), ensure_ascii=False),
                1 if dados.get("ativo", True) else 0,
                dados["cpf"],
            ),
        )
        if cur.rowcount == 0:
            raise CadastroErro("Usuário não encontrado.")
        self._conexao.commit()

    def remover_aluno(self, cpf):
        from core.excecoes import CadastroErro

        cpf_limpo = self._cpf_limpo(cpf)
        cur = self._conexao.cursor()
        cur.execute("DELETE FROM alunos WHERE cpf = ?", (cpf_limpo,))
        if cur.rowcount == 0:
            raise CadastroErro("Usuário não encontrado.")
        cur.execute("DELETE FROM pagamentos WHERE aluno_cpf = ?", (cpf_limpo,))
        self._conexao.commit()
