from core.repositorio.alunos import RepositorioAlunosMixin
from core.repositorio.base import RepositorioBase
from core.repositorio.instrutores import RepositorioInstrutoresMixin
from core.repositorio.pagamentos import RepositorioPagamentosMixin
from core.repositorio.planos import RepositorioPlanosMixin
from core.repositorio.treinos import RepositorioTreinosMixin


class RepositorioAcademia(
    RepositorioBase,
    RepositorioAlunosMixin,
    RepositorioPlanosMixin,
    RepositorioPagamentosMixin,
    RepositorioInstrutoresMixin,
    RepositorioTreinosMixin,
):
    """Fachada que agrupa repositórios por entidade."""
