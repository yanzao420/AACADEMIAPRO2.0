"""Persistência SQLite — repositório por entidade."""

from core.repositorio.academia import RepositorioAcademia
from core.repositorio.base import ARQUIVO_DB

__all__ = ["ARQUIVO_DB", "RepositorioAcademia"]
