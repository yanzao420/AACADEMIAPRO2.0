class RepositorioTreinosMixin:

    def listar_catalogo_treinos(self):
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM catalogo_treinos ORDER BY nome")
        return [dict(row) for row in cur.fetchall()]

    def buscar_treino_catalogo(self, id_treino):
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM catalogo_treinos WHERE id = ?", (id_treino,))
        row = cur.fetchone()
        return dict(row) if row else None

    def adicionar_treino_catalogo(self, id_treino, nome, duracao_minutos, descricao=""):
        from core.excecoes import CadastroErro

        if self.buscar_treino_catalogo(id_treino):
            raise CadastroErro("Já existe um treino com este identificador.")
        self._conexao.execute(
            """
            INSERT INTO catalogo_treinos (id, nome, duracao_minutos, descricao)
            VALUES (?, ?, ?, ?)
            """,
            (id_treino, nome, int(duracao_minutos), (descricao or "").strip()),
        )
        self._conexao.commit()

    def atualizar_treino_catalogo(self, id_treino, nome, duracao_minutos, descricao=""):
        from core.excecoes import CadastroErro

        if not self.buscar_treino_catalogo(id_treino):
            raise CadastroErro("Treino não encontrado no catálogo.")
        self._conexao.execute(
            """
            UPDATE catalogo_treinos
            SET nome = ?, duracao_minutos = ?, descricao = ?
            WHERE id = ?
            """,
            (nome, int(duracao_minutos), (descricao or "").strip(), id_treino),
        )
        self._conexao.commit()

    def remover_treino_catalogo(self, id_treino):
        from core.excecoes import CadastroErro

        cur = self._conexao.cursor()
        cur.execute("DELETE FROM catalogo_treinos WHERE id = ?", (id_treino,))
        if cur.rowcount == 0:
            raise CadastroErro("Treino não encontrado no catálogo.")
        self._conexao.commit()
