from models.pagamento import Pagamento


class RepositorioPagamentosMixin:

    def listar_pagamentos(self):
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM pagamentos ORDER BY vencimento")
        pagamentos = [Pagamento.from_dict(dict(row)) for row in cur.fetchall()]
        for pagamento in pagamentos:
            pagamento.atualizar_status_por_vencimento()
        return pagamentos

    def buscar_pagamento_por_id(self, id_pagamento):
        for pagamento in self.listar_pagamentos():
            if pagamento.id == id_pagamento:
                return pagamento
        return None

    def adicionar_pagamento(self, pagamento):
        dados = pagamento.to_dict()
        self._conexao.execute(
            """
            INSERT INTO pagamentos (
                id, aluno_cpf, valor, vencimento, status, plano_id, descricao
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                dados["id"],
                dados["aluno_cpf"],
                dados["valor"],
                dados["vencimento"],
                dados["status"],
                dados["plano_id"],
                dados["descricao"],
            ),
        )
        self._conexao.commit()

    def atualizar_pagamento(self, pagamento):
        from core.excecoes import CadastroErro

        dados = pagamento.to_dict()
        cur = self._conexao.cursor()
        cur.execute(
            """
            UPDATE pagamentos SET
                aluno_cpf = ?, valor = ?, vencimento = ?, status = ?,
                plano_id = ?, descricao = ?
            WHERE id = ?
            """,
            (
                dados["aluno_cpf"],
                dados["valor"],
                dados["vencimento"],
                dados["status"],
                dados["plano_id"],
                dados["descricao"],
                dados["id"],
            ),
        )
        if cur.rowcount == 0:
            raise CadastroErro("Pagamento não encontrado.")
        self._conexao.commit()

    def remover_pagamento(self, id_pagamento):
        from core.excecoes import CadastroErro

        cur = self._conexao.cursor()
        cur.execute("DELETE FROM pagamentos WHERE id = ?", (id_pagamento,))
        if cur.rowcount == 0:
            raise CadastroErro("Pagamento não encontrado.")
        self._conexao.commit()

    def remover_pagamentos_por_plano(self, plano_id):
        self._conexao.execute(
            "DELETE FROM pagamentos WHERE plano_id = ?",
            (plano_id,),
        )
        self._conexao.commit()
