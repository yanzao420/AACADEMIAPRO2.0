from models.plano import Plano


class RepositorioPlanosMixin:

    def listar_planos(self):
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM planos ORDER BY nome")
        return [Plano.from_dict(dict(row)) for row in cur.fetchall()]

    def buscar_plano_por_id(self, id_plano):
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM planos WHERE id = ?", (id_plano,))
        row = cur.fetchone()
        return Plano.from_dict(dict(row)) if row else None

    def adicionar_plano(self, plano):
        dados = plano.to_dict()
        self._conexao.execute(
            """
            INSERT INTO planos (id, nome, valor, duracao_meses)
            VALUES (?, ?, ?, ?)
            """,
            (dados["id"], dados["nome"], dados["valor"], dados["duracao_meses"]),
        )
        self._conexao.commit()

    def atualizar_plano(self, plano):
        from core.excecoes import CadastroErro

        dados = plano.to_dict()
        cur = self._conexao.cursor()
        cur.execute(
            """
            UPDATE planos SET nome = ?, valor = ?, duracao_meses = ? WHERE id = ?
            """,
            (dados["nome"], dados["valor"], dados["duracao_meses"], dados["id"]),
        )
        if cur.rowcount == 0:
            raise CadastroErro("Plano não encontrado.")
        self._conexao.commit()

    def remover_plano(self, id_plano):
        from core.excecoes import CadastroErro

        cur = self._conexao.cursor()
        cur.execute("DELETE FROM planos WHERE id = ?", (id_plano,))
        if cur.rowcount == 0:
            raise CadastroErro("Plano não encontrado.")
        self._conexao.commit()
