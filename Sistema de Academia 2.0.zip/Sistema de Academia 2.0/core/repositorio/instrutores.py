from models.instrutor import Instrutor


class RepositorioInstrutoresMixin:

    def listar_instrutores(self):
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM instrutores ORDER BY nome")
        return [Instrutor.from_dict(dict(row)) for row in cur.fetchall()]

    def buscar_instrutor_por_cpf(self, cpf):
        cpf_limpo = self._cpf_limpo(cpf)
        cur = self._conexao.cursor()
        cur.execute("SELECT * FROM instrutores WHERE cpf = ?", (cpf_limpo,))
        row = cur.fetchone()
        return Instrutor.from_dict(dict(row)) if row else None

    def adicionar_instrutor(self, instrutor):
        from core.excecoes import CadastroErro

        if self.buscar_instrutor_por_cpf(instrutor.cpf):
            raise CadastroErro("Já existe um instrutor com este CPF.")
        dados = instrutor.to_dict()
        self._conexao.execute(
            """
            INSERT INTO instrutores (cpf, nome, especialidade)
            VALUES (?, ?, ?)
            """,
            (dados["cpf"], dados["nome"], dados["especialidade"]),
        )
        self._conexao.commit()

    def atualizar_instrutor(self, instrutor):
        from core.excecoes import CadastroErro

        dados = instrutor.to_dict()
        cur = self._conexao.cursor()
        cur.execute(
            """
            UPDATE instrutores SET nome = ?, especialidade = ? WHERE cpf = ?
            """,
            (dados["nome"], dados["especialidade"], dados["cpf"]),
        )
        if cur.rowcount == 0:
            raise CadastroErro("Instrutor não encontrado.")
        self._conexao.commit()

    def remover_instrutor(self, cpf):
        from core.excecoes import CadastroErro

        cpf_limpo = self._cpf_limpo(cpf)
        cur = self._conexao.cursor()
        cur.execute("DELETE FROM instrutores WHERE cpf = ?", (cpf_limpo,))
        if cur.rowcount == 0:
            raise CadastroErro("Instrutor não encontrado.")
        cur.execute(
            """
            UPDATE alunos SET instrutor_cpf = NULL
            WHERE REPLACE(REPLACE(REPLACE(COALESCE(instrutor_cpf, ''), '.', ''), '-', ''), ' ', '') = ?
            """,
            (cpf_limpo,),
        )
        self._conexao.commit()
