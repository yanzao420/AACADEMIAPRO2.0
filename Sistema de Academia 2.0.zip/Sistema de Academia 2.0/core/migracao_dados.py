"""Importa dados do academia.json para SQLite (executado uma vez)."""
import json
from pathlib import Path

from core.catalogo_treinos import CATALOGO_TREINOS_PADRAO

BASE_DIR = Path(__file__).resolve().parent.parent
ARQUIVO_JSON = BASE_DIR / "database" / "academia.json"


def migrar_json_para_sqlite(conexao):
    if not ARQUIVO_JSON.exists():
        return False

    cur = conexao.cursor()
    cur.execute("SELECT COUNT(*) FROM alunos")
    if cur.fetchone()[0] > 0:
        return False

    with open(ARQUIVO_JSON, encoding="utf-8") as arquivo:
        dados = json.load(arquivo)

    for item in dados.get("alunos", []):
        cur.execute(
            """
            INSERT INTO alunos (
                cpf, nome_completo, data_nascimento, email, telefone,
                observacoes, plano_id, instrutor_cpf, treinos_json, ativo
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "".join(filter(str.isdigit, item.get("cpf", ""))),
                item.get("nome_completo", ""),
                item.get("data_nascimento", ""),
                item.get("email", ""),
                item.get("telefone", ""),
                item.get("observacoes", ""),
                item.get("plano_id"),
                item.get("instrutor_cpf"),
                json.dumps(item.get("treinos", []), ensure_ascii=False),
                1 if item.get("ativo", True) else 0,
            ),
        )

    for item in dados.get("planos", []):
        cur.execute(
            """
            INSERT INTO planos (id, nome, valor, duracao_meses)
            VALUES (?, ?, ?, ?)
            """,
            (
                item["id"],
                item["nome"],
                item["valor"],
                item["duracao_meses"],
            ),
        )

    for item in dados.get("pagamentos", []):
        cur.execute(
            """
            INSERT INTO pagamentos (
                id, aluno_cpf, valor, vencimento, status, plano_id, descricao
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                item["id"],
                item["aluno_cpf"],
                item["valor"],
                item["vencimento"],
                item.get("status", "pendente"),
                item.get("plano_id"),
                item.get("descricao", ""),
            ),
        )

    for item in dados.get("instrutores", []):
        cur.execute(
            """
            INSERT INTO instrutores (cpf, nome, especialidade)
            VALUES (?, ?, ?)
            """,
            (
                "".join(filter(str.isdigit, item.get("cpf", ""))),
                item.get("nome", ""),
                item.get("especialidade", ""),
            ),
        )

    catalogo = dados.get("catalogo_treinos") or list(CATALOGO_TREINOS_PADRAO)
    for item in catalogo:
        cur.execute(
            """
            INSERT OR IGNORE INTO catalogo_treinos (id, nome, duracao_minutos, descricao)
            VALUES (?, ?, ?, ?)
            """,
            (
                item["id"],
                item["nome"],
                item.get("duracao_minutos", 60),
                item.get("descricao", ""),
            ),
        )

    conexao.commit()
    return True
