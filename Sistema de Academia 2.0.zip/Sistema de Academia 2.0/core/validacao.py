import re
from datetime import datetime

from core.excecoes import ValidacaoErro


def _apenas_digitos(valor):
    return re.sub(r"\D", "", valor or "")


def validar_nome(nome):
    nome = (nome or "").strip()
    if len(nome) < 3:
        raise ValidacaoErro("Informe o nome completo (mínimo 3 caracteres).")
    if len(nome.split()) < 2:
        raise ValidacaoErro("Informe nome e sobrenome.")
    return nome


def validar_cpf(cpf):
    cpf = _apenas_digitos(cpf)
    if len(cpf) != 11 or cpf == cpf[0] * 11:
        raise ValidacaoErro("CPF inválido.")

    soma = sum(int(cpf[i]) * (10 - i) for i in range(9))
    digito1 = (soma * 10 % 11) % 10
    soma = sum(int(cpf[i]) * (11 - i) for i in range(10))
    digito2 = (soma * 10 % 11) % 10

    if int(cpf[9]) != digito1 or int(cpf[10]) != digito2:
        raise ValidacaoErro("CPF inválido.")

    return cpf


def validar_email(email):
    email = (email or "").strip().lower()
    padrao = r"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
    if not re.match(padrao, email):
        raise ValidacaoErro("E-mail inválido.")
    return email


def validar_telefone(telefone):
    telefone = (telefone or "").strip()
    if not telefone:
        return ""
    digitos = _apenas_digitos(telefone)
    if len(digitos) not in (10, 11):
        raise ValidacaoErro("Telefone inválido. Use DDD + número (10 ou 11 dígitos).")
    return digitos


def validar_data_nascimento(data_texto):
    return _validar_data(data_texto, "A data de nascimento deve ser anterior a hoje.", anterior_hoje=True)


def validar_data_vencimento(data_texto):
    return _validar_data(data_texto, "Informe uma data de vencimento válida.", anterior_hoje=False)


def _validar_data(data_texto, mensagem_erro, anterior_hoje=False):
    data_texto = (data_texto or "").strip()
    try:
        data = datetime.strptime(data_texto, "%d/%m/%Y").date()
    except ValueError as exc:
        raise ValidacaoErro("Data inválida. Use o formato DD/MM/AAAA.") from exc

    if anterior_hoje and data >= datetime.now().date():
        raise ValidacaoErro(mensagem_erro)

    return data.strftime("%d/%m/%Y")


def validar_valor_monetario(valor_texto):
    texto = (valor_texto or "").strip().replace("R$", "").replace(" ", "")
    texto = texto.replace(".", "").replace(",", ".")
    try:
        valor = float(texto)
    except ValueError as exc:
        raise ValidacaoErro("Valor inválido.") from exc
    if valor <= 0:
        raise ValidacaoErro("O valor deve ser maior que zero.")
    return round(valor, 2)


def validar_duracao_meses(duracao):
    texto = str(duracao or "").strip()
    if not texto:
        return 1
    try:
        meses = int(texto)
    except (TypeError, ValueError) as exc:
        raise ValidacaoErro("Duração inválida (informe meses em número inteiro).") from exc
    if meses < 1:
        raise ValidacaoErro("A duração deve ser de pelo menos 1 mês.")
    return meses


def validar_status_pagamento(status):
    from models.pagamento import Pagamento

    mapa = {
        "pago": Pagamento.STATUS_PAGO,
        "pendente": Pagamento.STATUS_PENDENTE,
        "atrasado": Pagamento.STATUS_ATRASADO,
    }
    chave = (status or "").strip().lower()
    if chave not in mapa:
        raise ValidacaoErro("Status de pagamento inválido.")
    return mapa[chave]


def validar_nome_plano(nome):
    nome = (nome or "").strip()
    if len(nome) < 2:
        raise ValidacaoErro("Informe o nome do plano.")
    return nome


def validar_nome_treino(nome):
    nome = (nome or "").strip()
    if len(nome) < 2:
        raise ValidacaoErro("Informe o nome do treino.")
    return nome


def validar_duracao_treino(duracao):
    texto = str(duracao or "").strip()
    try:
        minutos = int(texto)
    except (TypeError, ValueError) as exc:
        raise ValidacaoErro("Duração inválida (informe minutos em número inteiro).") from exc
    if minutos < 10 or minutos > 300:
        raise ValidacaoErro("A duração deve ficar entre 10 e 300 minutos.")
    return minutos
