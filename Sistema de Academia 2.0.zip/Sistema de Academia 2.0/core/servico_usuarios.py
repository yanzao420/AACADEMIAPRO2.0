import csv
from pathlib import Path

from datetime import datetime

from core.decoradores import registrar_operacao, requer_permissao
from core.excecoes import CadastroErro, ValidacaoErro
from core.relatorio import gerar_relatorio_pessoas
from core.util_datas import adicionar_meses
from core.repositorio import RepositorioAcademia
from core.servico_pagamentos import ServicoPagamentos
from core.validacao import (
    validar_cpf,
    validar_data_nascimento,
    validar_email,
    validar_nome,
    validar_telefone,
)
from models.aluno import Aluno
from models.pessoa import Pessoa

BASE_DIR = Path(__file__).resolve().parent.parent


class ServicoUsuarios:

    def __init__(self, repositorio=None):
        self.repositorio = repositorio or RepositorioAcademia()

    def _criar_aluno_dados(
        self,
        nome,
        cpf,
        data_nascimento,
        email,
        telefone="",
        observacoes="",
        plano_id=None,
        instrutor_cpf=None,
        treinos=None,
        ativo=True,
    ):
        instrutor_limpo = None
        if instrutor_cpf:
            instrutor_limpo = validar_cpf(instrutor_cpf)

        return Aluno(
            nome_completo=validar_nome(nome),
            cpf=validar_cpf(cpf),
            data_nascimento=validar_data_nascimento(data_nascimento),
            email=validar_email(email),
            telefone=validar_telefone(telefone),
            observacoes=(observacoes or "").strip(),
            plano_id=plano_id or None,
            instrutor_cpf=instrutor_limpo,
            treinos=treinos,
            ativo=ativo,
        )

    @registrar_operacao("cadastrar_usuario")
    def cadastrar(
        self,
        nome,
        cpf,
        data_nascimento,
        email,
        telefone="",
        observacoes="",
        plano_id=None,
        instrutor_cpf=None,
        data_primeiro_vencimento=None,
        status_pagamento="pendente",
        usuario=None,
    ):
        if instrutor_cpf:
            instrutor = self.repositorio.buscar_instrutor_por_cpf(instrutor_cpf)
            if not instrutor:
                raise CadastroErro("Instrutor selecionado não encontrado.")

        aluno = self._criar_aluno_dados(
            nome,
            cpf,
            data_nascimento,
            email,
            telefone,
            observacoes,
            plano_id,
            instrutor_cpf=instrutor_cpf,
        )
        self.repositorio.adicionar_aluno(aluno)

        parcelas = []
        if plano_id:
            if not data_primeiro_vencimento:
                raise ValidacaoErro(
                    "Informe a data do 1º vencimento para gerar as mensalidades."
                )
            parcelas = ServicoPagamentos(self.repositorio).gerar_parcelas_mensais(
                aluno.cpf,
                plano_id,
                data_primeiro_vencimento,
                status_pagamento,
            )

        aluno.parcelas_geradas = len(parcelas)
        return aluno

    @registrar_operacao("atualizar_usuario")
    def atualizar(
        self,
        cpf,
        nome,
        data_nascimento,
        email,
        telefone="",
        observacoes="",
        plano_id=None,
        instrutor_cpf=None,
        data_primeiro_vencimento=None,
        status_pagamento="pendente",
        treinos=None,
        ativo=True,
        usuario=None,
    ):
        cpf_busca = validar_cpf(cpf)
        existente = self.repositorio.buscar_aluno_por_cpf(cpf_busca)
        if not existente:
            raise CadastroErro("Usuário não encontrado.")

        if instrutor_cpf:
            instrutor = self.repositorio.buscar_instrutor_por_cpf(instrutor_cpf)
            if not instrutor:
                raise CadastroErro("Instrutor selecionado não encontrado.")

        plano_anterior = existente.plano_id
        plano_novo = plano_id or None
        treinos_finais = treinos if treinos is not None else existente._treinos

        aluno = self._criar_aluno_dados(
            nome,
            cpf_busca,
            data_nascimento,
            email,
            telefone,
            observacoes,
            plano_novo,
            instrutor_cpf=instrutor_cpf or None,
            treinos=treinos_finais,
            ativo=ativo,
        )
        self.repositorio.atualizar_aluno(aluno)

        pagamentos_svc = ServicoPagamentos(self.repositorio)
        parcelas_geradas = 0

        if plano_anterior != plano_novo:
            parcelas = pagamentos_svc.atualizar_mensalidades_plano(
                aluno.cpf,
                plano_anterior,
                plano_novo,
                data_primeiro_vencimento,
                status_pagamento,
            )
            parcelas_geradas = len(parcelas)

        if plano_novo:
            pagamentos_plano = [
                p
                for p in pagamentos_svc._pagamentos_do_aluno(aluno.cpf)
                if p.plano_id == plano_novo
            ]
            if not pagamentos_plano:
                vencimento = data_primeiro_vencimento
                if not vencimento:
                    hoje = datetime.now().strftime("%d/%m/%Y")
                    vencimento = adicionar_meses(hoje, 1)
                novas = pagamentos_svc.gerar_parcelas_mensais(
                    aluno.cpf,
                    plano_novo,
                    vencimento,
                    status_pagamento,
                )
                parcelas_geradas = len(novas)

        aluno.parcelas_geradas = parcelas_geradas
        return aluno

    @registrar_operacao("vincular_instrutor_aluno")
    def vincular_instrutor(self, cpf_aluno, cpf_instrutor, usuario=None):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf_aluno)
        if not aluno:
            raise CadastroErro("Aluno não encontrado.")

        instrutor_cpf = None
        if cpf_instrutor:
            instrutor = self.repositorio.buscar_instrutor_por_cpf(cpf_instrutor)
            if not instrutor:
                raise CadastroErro("Instrutor não encontrado.")
            instrutor_cpf = validar_cpf(cpf_instrutor)

        aluno.instrutor_cpf = instrutor_cpf
        self.repositorio.atualizar_aluno(aluno)
        return aluno

    def listar(self, termo_busca="", apenas_ativos=False):
        alunos = self.repositorio.listar_alunos(apenas_ativos=apenas_ativos)
        if not termo_busca:
            return alunos
        termo = termo_busca.strip().lower()
        resultado = []
        for aluno in alunos:
            texto = " ".join(
                [
                    aluno.nome,
                    aluno.cpf,
                    aluno.email,
                    aluno.telefone,
                    aluno.observacoes,
                ]
            ).lower()
            if termo in texto:
                resultado.append(aluno)
        return resultado

    def buscar_por_cpf(self, cpf):
        return self.repositorio.buscar_aluno_por_cpf(cpf)

    @registrar_operacao("alternar_status_usuario")
    def alternar_status(self, cpf, usuario=None):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        if not aluno:
            raise CadastroErro("Usuário não encontrado.")
        aluno.ativo = not aluno.ativo
        self.repositorio.atualizar_aluno(aluno)
        return aluno

    @requer_permissao("pode_remover")
    @registrar_operacao("remover_usuario")
    def remover(self, cpf, usuario=None):
        self.repositorio.remover_aluno(cpf)

    def listar_pessoas_polimorfismo(self) -> list[Pessoa]:
        pessoas: list[Pessoa] = list(self.repositorio.listar_alunos())
        pessoas.extend(self.repositorio.listar_instrutores())
        return pessoas

    def relatorio_pessoas(self) -> str:
        return gerar_relatorio_pessoas(self.listar_pessoas_polimorfismo())

    def exportar_csv(self, caminho_arquivo):
        caminho = Path(caminho_arquivo)
        planos = {p.id: p.nome for p in self.repositorio.listar_planos()}

        with open(caminho, "w", newline="", encoding="utf-8-sig") as arquivo:
            writer = csv.writer(arquivo, delimiter=";")
            writer.writerow(
                [
                    "Nome",
                    "CPF",
                    "Nascimento",
                    "E-mail",
                    "Telefone",
                    "Plano",
                    "Status",
                    "Observações",
                ]
            )
            for aluno in self.listar():
                writer.writerow(
                    [
                        aluno.nome,
                        self.formatar_cpf(aluno.cpf),
                        aluno.data_nascimento,
                        aluno.email,
                        self.formatar_telefone(aluno.telefone),
                        planos.get(aluno.plano_id, "—"),
                        "Ativo" if aluno.ativo else "Inativo",
                        aluno.observacoes,
                    ]
                )
        return caminho

    @staticmethod
    def formatar_cpf(cpf):
        digitos = "".join(filter(str.isdigit, cpf or ""))
        if len(digitos) != 11:
            return cpf
        return f"{digitos[:3]}.{digitos[3:6]}.{digitos[6:9]}-{digitos[9:]}"

    @staticmethod
    def formatar_telefone(telefone):
        digitos = "".join(filter(str.isdigit, telefone or ""))
        if len(digitos) == 11:
            return f"({digitos[:2]}) {digitos[2:7]}-{digitos[7:]}"
        if len(digitos) == 10:
            return f"({digitos[:2]}) {digitos[2:6]}-{digitos[6:]}"
        return telefone or ""
