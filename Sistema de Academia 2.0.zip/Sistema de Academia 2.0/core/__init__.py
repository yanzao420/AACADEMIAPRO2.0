"""Regras de negócio, persistência, validação e serviços."""
