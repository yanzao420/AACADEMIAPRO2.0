from models.pagamento import Pagamento


class PagamentosInadimplenciaMixin:

    def _desativar_inadimplentes(self):
        for aluno in self.repositorio.listar_alunos():
            if not aluno.plano_id:
                continue
            pagamentos = self._pagamentos_do_aluno(aluno.cpf)
            if not pagamentos:
                continue
            self._atualizar_status_local(pagamentos)
            if any(p.status == Pagamento.STATUS_ATRASADO for p in pagamentos):
                if aluno.ativo:
                    aluno.ativo = False
                    self.repositorio.atualizar_aluno(aluno)

    def _reativar_se_regularizado(self, cpf):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        if not aluno or aluno.ativo:
            return
        pagamentos = self._pagamentos_do_aluno(cpf)
        self._atualizar_status_local(pagamentos)
        if not any(p.status == Pagamento.STATUS_ATRASADO for p in pagamentos):
            aluno.ativo = True
            self.repositorio.atualizar_aluno(aluno)

    def aluno_inadimplente(self, cpf):
        pagamentos = self._pagamentos_do_aluno(cpf)
        if not pagamentos:
            return False
        self._atualizar_status_local(pagamentos)
        return any(p.status == Pagamento.STATUS_ATRASADO for p in pagamentos)
