from datetime import datetime

from models.pagamento import Pagamento


class PagamentosConsultasMixin:

    def listar(self):
        self.sincronizar_mensalidades()
        pagamentos = self.repositorio.listar_pagamentos()
        for p in pagamentos:
            p.atualizar_status_por_vencimento()
            if p.status == Pagamento.STATUS_ATRASADO:
                self.repositorio.atualizar_pagamento(p)
        return self.repositorio.listar_pagamentos()

    def _pagamentos_do_aluno(self, cpf):
        cpf_limpo = "".join(filter(str.isdigit, cpf or ""))
        pagamentos = [
            p
            for p in self.repositorio.listar_pagamentos()
            if p.aluno_cpf == cpf_limpo
        ]
        pagamentos.sort(
            key=lambda p: datetime.strptime(p.vencimento, "%d/%m/%Y")
        )
        return pagamentos

    def _atualizar_status_local(self, pagamentos):
        for pagamento in pagamentos:
            status_anterior = pagamento.status
            pagamento.atualizar_status_por_vencimento()
            if pagamento.status != status_anterior:
                self.repositorio.atualizar_pagamento(pagamento)

    def listar_por_aluno(self, cpf):
        cpf_limpo = "".join(filter(str.isdigit, cpf or ""))
        return [p for p in self.listar() if p.aluno_cpf == cpf_limpo]

    def listar_por_status(self, status):
        return [p for p in self.listar() if p.status == status]

    def nome_aluno(self, cpf):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        return aluno.nome if aluno else cpf

    def resumo_status_aluno(self, cpf):
        pagamentos = self.listar_por_aluno(cpf)
        if not pagamentos:
            return "Sem mensalidade"

        atrasados = sum(
            1 for p in pagamentos if p.status == Pagamento.STATUS_ATRASADO
        )
        pendentes = sum(
            1 for p in pagamentos if p.status == Pagamento.STATUS_PENDENTE
        )
        pagos = sum(1 for p in pagamentos if p.status == Pagamento.STATUS_PAGO)

        if atrasados:
            return f"{atrasados} atrasada(s)"
        if pendentes:
            return f"{pendentes} pendente(s)"
        if pagos == len(pagamentos):
            return "Em dia"
        return "Em dia"
