from core.decoradores import registrar_operacao, requer_permissao
from core.excecoes import CadastroErro
from core.validacao import (
    validar_data_vencimento,
    validar_status_pagamento,
    validar_valor_monetario,
)
from models.pagamento import Pagamento


class PagamentosOperacoesMixin:

    @requer_permissao("pode_gerenciar_pagamentos")
    @registrar_operacao("registrar_pagamento")
    def registrar(
        self,
        aluno_cpf,
        valor,
        vencimento,
        plano_id=None,
        descricao="",
        status=None,
        usuario=None,
    ):
        aluno = self.repositorio.buscar_aluno_por_cpf(aluno_cpf)
        if not aluno:
            raise CadastroErro("Aluno não encontrado.")

        status_final = Pagamento.STATUS_PENDENTE
        if status:
            status_final = validar_status_pagamento(status)

        pagamento = Pagamento(
            id_pagamento=self.repositorio._novo_id("pag"),
            aluno_cpf=aluno.cpf,
            valor=validar_valor_monetario(valor),
            vencimento=validar_data_vencimento(vencimento),
            status=status_final,
            plano_id=plano_id,
            descricao=(descricao or "").strip(),
        )
        pagamento.atualizar_status_por_vencimento()
        self.repositorio.adicionar_pagamento(pagamento)
        return pagamento

    @requer_permissao("pode_gerenciar_pagamentos")
    @registrar_operacao("marcar_pagamento_pago")
    def marcar_como_pago(self, id_pagamento, usuario=None):
        pagamento = self.repositorio.buscar_pagamento_por_id(id_pagamento)
        if not pagamento:
            raise CadastroErro("Pagamento não encontrado.")
        pagamento.marcar_pago()
        self.repositorio.atualizar_pagamento(pagamento)
        self._reativar_se_regularizado(pagamento.aluno_cpf)
        aluno = self.repositorio.buscar_aluno_por_cpf(pagamento.aluno_cpf)
        proximo = None
        if aluno:
            proximo = self._tentar_renovar_mensalidade_aluno(
                aluno,
                exigir_vencimento_passado=False,
            )
        pagamento.proximo_mensalidade = proximo
        return pagamento

    @requer_permissao("pode_gerenciar_pagamentos")
    @registrar_operacao("remover_pagamento")
    def remover(self, id_pagamento, usuario=None):
        self.repositorio.remover_pagamento(id_pagamento)

    def remover_por_aluno(self, cpf):
        for pagamento in self._pagamentos_do_aluno(cpf):
            self.repositorio.remover_pagamento(pagamento.id)

    def remover_por_plano(self, plano_id):
        if not plano_id:
            return
        for pagamento in self.repositorio.listar_pagamentos():
            if pagamento.plano_id == plano_id:
                self.repositorio.remover_pagamento(pagamento.id)
