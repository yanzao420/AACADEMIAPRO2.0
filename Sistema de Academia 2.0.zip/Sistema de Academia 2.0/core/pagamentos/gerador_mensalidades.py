from datetime import datetime

from core.excecoes import CadastroErro
from core.util_datas import adicionar_meses
from core.validacao import validar_data_vencimento, validar_status_pagamento
from models.pagamento import Pagamento


class PagamentosGeradorMixin:

    def gerar_parcelas_mensais(
        self,
        aluno_cpf,
        plano_id,
        data_primeiro_vencimento,
        status_inicial="pendente",
    ):
        plano = self.repositorio.buscar_plano_por_id(plano_id)
        if not plano:
            raise CadastroErro("Plano não encontrado para gerar pagamentos.")

        aluno = self.repositorio.buscar_aluno_por_cpf(aluno_cpf)
        if not aluno:
            raise CadastroErro("Aluno não encontrado.")

        data_base = validar_data_vencimento(data_primeiro_vencimento)
        status_primeira = validar_status_pagamento(status_inicial)
        parcelas = []
        meses = max(1, int(plano.duracao_meses or 1))

        for indice in range(meses):
            vencimento = (
                data_base
                if indice == 0
                else adicionar_meses(data_base, indice)
            )
            if indice == 0:
                status = status_primeira
            else:
                status = Pagamento.STATUS_PENDENTE

            pagamento = Pagamento(
                id_pagamento=self.repositorio._novo_id("pag"),
                aluno_cpf=aluno.cpf,
                valor=plano.valor,
                vencimento=vencimento,
                status=status,
                plano_id=plano.id,
                descricao=f"Mensalidade {indice + 1}/{meses} — {plano.nome}",
            )
            pagamento.atualizar_status_por_vencimento()
            self.repositorio.adicionar_pagamento(pagamento)
            parcelas.append(pagamento)

        return parcelas

    def gerar_mensalidades_iniciais_faltantes(self):
        hoje = datetime.now().strftime("%d/%m/%Y")
        vencimento_padrao = adicionar_meses(hoje, 1)

        for aluno in self.repositorio.listar_alunos(apenas_ativos=True):
            if not aluno.plano_id:
                continue
            if not self.repositorio.buscar_plano_por_id(aluno.plano_id):
                continue

            pagamentos = self._pagamentos_do_aluno(aluno.cpf)
            pagamentos_plano = [
                p for p in pagamentos if p.plano_id == aluno.plano_id
            ]

            if pagamentos and not pagamentos_plano:
                self.remover_por_aluno(aluno.cpf)
                pagamentos_plano = []

            if pagamentos_plano:
                continue

            self.gerar_parcelas_mensais(
                aluno.cpf,
                aluno.plano_id,
                vencimento_padrao,
                Pagamento.STATUS_PENDENTE,
            )

    def renovar_mensalidades_recorrentes(self):
        for aluno in self.repositorio.listar_alunos(apenas_ativos=True):
            self._tentar_renovar_mensalidade_aluno(
                aluno,
                exigir_vencimento_passado=True,
            )

    def _tentar_renovar_mensalidade_aluno(
        self,
        aluno,
        exigir_vencimento_passado=True,
    ):
        if not aluno.plano_id:
            return None
        plano = self.repositorio.buscar_plano_por_id(aluno.plano_id)
        if not plano:
            return None

        pagamentos = self._pagamentos_do_aluno(aluno.cpf)
        if not pagamentos:
            return None

        self._atualizar_status_local(pagamentos)

        if any(p.status == Pagamento.STATUS_ATRASADO for p in pagamentos):
            return None

        ultimo = pagamentos[-1]
        if ultimo.status != Pagamento.STATUS_PAGO:
            return None

        if exigir_vencimento_passado:
            hoje = datetime.now().date()
            ultimo_dt = datetime.strptime(ultimo.vencimento, "%d/%m/%Y").date()
            if hoje < ultimo_dt:
                return None

        proximo_venc = adicionar_meses(ultimo.vencimento, 1)
        if any(p.vencimento == proximo_venc for p in pagamentos):
            return None

        pagamento = Pagamento(
            id_pagamento=self.repositorio._novo_id("pag"),
            aluno_cpf=aluno.cpf,
            valor=plano.valor,
            vencimento=proximo_venc,
            status=Pagamento.STATUS_PENDENTE,
            plano_id=plano.id,
            descricao=f"MENSALIDADE — {plano.nome} ({proximo_venc})",
        )
        pagamento.atualizar_status_por_vencimento()
        self.repositorio.adicionar_pagamento(pagamento)
        return pagamento

    def gerar_mensalidades_para_aluno(self, cpf, data_primeiro_vencimento=None):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        if not aluno:
            raise CadastroErro("Membro não encontrado.")
        if not aluno.plano_id:
            raise CadastroErro("Membro sem plano vinculado.")
        if not self.repositorio.buscar_plano_por_id(aluno.plano_id):
            raise CadastroErro("Plano do membro não encontrado.")

        pagamentos_plano = [
            p
            for p in self._pagamentos_do_aluno(aluno.cpf)
            if p.plano_id == aluno.plano_id
        ]
        if pagamentos_plano:
            raise CadastroErro("Membro já possui mensalidades do plano atual.")

        if not data_primeiro_vencimento:
            hoje = datetime.now().strftime("%d/%m/%Y")
            data_primeiro_vencimento = adicionar_meses(hoje, 1)

        return self.gerar_parcelas_mensais(
            aluno.cpf,
            aluno.plano_id,
            data_primeiro_vencimento,
            Pagamento.STATUS_PENDENTE,
        )

    def atualizar_mensalidades_plano(
        self,
        cpf,
        plano_id_anterior,
        plano_id_novo,
        data_primeiro_vencimento=None,
        status_pagamento="pendente",
    ):
        plano_anterior = plano_id_anterior or None
        plano_novo = plano_id_novo or None
        if plano_anterior == plano_novo:
            return []

        self.remover_por_aluno(cpf)

        if not plano_novo:
            return []

        if not data_primeiro_vencimento:
            hoje = datetime.now().strftime("%d/%m/%Y")
            data_primeiro_vencimento = adicionar_meses(hoje, 1)

        return self.gerar_parcelas_mensais(
            cpf,
            plano_novo,
            data_primeiro_vencimento,
            status_pagamento,
        )
