"""Submódulos de regras financeiras."""
