from core.decoradores import registrar_operacao, requer_permissao
from core.excecoes import CadastroErro, ValidacaoErro
from core.repositorio import RepositorioAcademia
from core.validacao import validar_cpf, validar_nome
from models.instrutor import Instrutor


class ServicoInstrutores:

    def __init__(self, repositorio=None):
        self.repositorio = repositorio or RepositorioAcademia()

    def listar(self, termo_busca=""):
        instrutores = self.repositorio.listar_instrutores()
        if not termo_busca:
            return instrutores
        termo = termo_busca.strip().lower()
        return [
            i
            for i in instrutores
            if termo in f"{i.nome} {i.cpf} {i.especialidade}".lower()
        ]

    def buscar(self, cpf):
        return self.repositorio.buscar_instrutor_por_cpf(cpf)

    @registrar_operacao("cadastrar_instrutor")
    def cadastrar(self, nome, cpf, especialidade, usuario=None):
        instrutor = Instrutor(
            nome=validar_nome(nome),
            cpf=validar_cpf(cpf),
            especialidade=(especialidade or "").strip() or "Geral",
        )
        self.repositorio.adicionar_instrutor(instrutor)
        return instrutor

    @registrar_operacao("atualizar_instrutor")
    def atualizar(self, cpf, nome, especialidade, usuario=None):
        existente = self.repositorio.buscar_instrutor_por_cpf(cpf)
        if not existente:
            raise CadastroErro("Instrutor não encontrado.")
        instrutor = Instrutor(
            nome=validar_nome(nome),
            cpf=existente.cpf,
            especialidade=(especialidade or "").strip() or "Geral",
        )
        self.repositorio.atualizar_instrutor(instrutor)
        return instrutor

    @requer_permissao("pode_remover")
    @registrar_operacao("remover_instrutor")
    def remover(self, cpf, usuario=None):
        self.repositorio.remover_instrutor(cpf)

    def nome_instrutor(self, cpf):
        if not cpf:
            return "—"
        instrutor = self.buscar(cpf)
        return instrutor.nome if instrutor else "—"

    def alunos_vinculados(self, cpf_instrutor):
        return self.repositorio.listar_alunos_por_instrutor(cpf_instrutor)
