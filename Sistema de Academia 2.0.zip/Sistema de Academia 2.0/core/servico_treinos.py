import re
import unicodedata

from core.decoradores import registrar_operacao
from core.excecoes import CadastroErro
from core.repositorio import RepositorioAcademia
from core.validacao import validar_duracao_treino, validar_nome_treino
from models.treino import Treino


class ServicoTreinos:

    def __init__(self, repositorio=None):
        self.repositorio = repositorio or RepositorioAcademia()

    def listar_catalogo(self):
        return [
            Treino.from_dict(item)
            for item in self.repositorio.listar_catalogo_treinos()
        ]

    def buscar_no_catalogo(self, id_treino):
        dados = self.repositorio.buscar_treino_catalogo(id_treino)
        return Treino.from_dict(dados) if dados else None

    buscar_catalogo = buscar_no_catalogo

    def _descricao_catalogo(self, treino_id):
        if not treino_id:
            return ""
        catalogo = self.repositorio.buscar_treino_catalogo(treino_id)
        return (catalogo.get("descricao") or "").strip() if catalogo else ""

    def _enriquecer_treino(self, treino):
        if not treino.descricao:
            treino.descricao = self._descricao_catalogo(treino.id)
        return treino

    def treinos_do_aluno(self, cpf):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        if not aluno:
            return []
        treinos = []
        for dados in aluno.treinos:
            treino = self._enriquecer_treino(Treino.from_dict(dados))
            treinos.append(treino)
        return treinos

    @staticmethod
    def _slug_id(nome):
        base = unicodedata.normalize("NFKD", nome)
        base = base.encode("ascii", "ignore").decode("ascii")
        base = re.sub(r"[^a-zA-Z0-9]+", "_", base.lower()).strip("_")
        return f"treino_{base or 'personalizado'}"

    @registrar_operacao("cadastrar_treino_catalogo")
    def cadastrar_catalogo(self, nome, duracao_minutos, descricao="", usuario=None):
        nome_limpo = validar_nome_treino(nome)
        duracao = validar_duracao_treino(duracao_minutos)
        descricao_limpa = (descricao or "").strip()
        if len(descricao_limpa) < 5:
            raise CadastroErro("Informe a descrição do treino (mínimo 5 caracteres).")

        id_base = self._slug_id(nome_limpo)
        id_treino = id_base
        contador = 2
        while self.repositorio.buscar_treino_catalogo(id_treino):
            id_treino = f"{id_base}_{contador}"
            contador += 1

        self.repositorio.adicionar_treino_catalogo(
            id_treino,
            nome_limpo,
            duracao,
            descricao_limpa,
        )
        return self.buscar_no_catalogo(id_treino)

    @registrar_operacao("atualizar_treino_catalogo")
    def atualizar_catalogo(self, id_treino, nome, duracao_minutos, descricao="", usuario=None):
        if not id_treino:
            raise CadastroErro("Selecione um treino para editar.")
        nome_limpo = validar_nome_treino(nome)
        duracao = validar_duracao_treino(duracao_minutos)
        descricao_limpa = (descricao or "").strip()
        if len(descricao_limpa) < 5:
            raise CadastroErro("Informe a descrição do treino (mínimo 5 caracteres).")

        self.repositorio.atualizar_treino_catalogo(
            id_treino,
            nome_limpo,
            duracao,
            descricao_limpa,
        )
        self._propagar_treino_alunos(id_treino, nome_limpo, duracao, descricao_limpa)
        return self.buscar_no_catalogo(id_treino)

    def _propagar_treino_alunos(self, id_treino, nome, duracao, descricao):
        for aluno in self.repositorio.listar_alunos():
            alterou = False
            for treino in aluno._treinos:
                if treino.get("id") == id_treino:
                    treino["nome"] = nome
                    treino["duracao_minutos"] = duracao
                    treino["descricao"] = descricao
                    alterou = True
            if alterou:
                self.repositorio.atualizar_aluno(aluno)

    def definir_treinos_aluno(self, cpf, lista_treinos_dict, usuario=None):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        if not aluno:
            raise CadastroErro("Aluno não encontrado.")
        aluno._treinos = list(lista_treinos_dict)
        self.repositorio.atualizar_aluno(aluno)
        return aluno

    def adicionar_treino_ao_aluno(self, cpf, id_treino, usuario=None):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        if not aluno:
            raise CadastroErro("Aluno não encontrado.")
        treino = self.buscar_no_catalogo(id_treino)
        if not treino:
            raise CadastroErro("Treino não encontrado no catálogo.")
        if not treino.descricao:
            treino.descricao = self._descricao_catalogo(treino.id)
        ids = {t.get("id") for t in aluno._treinos}
        if treino.id not in ids:
            aluno.adicionar_treino(treino)
            self.repositorio.atualizar_aluno(aluno)
        return aluno

    def remover_treino_do_aluno(self, cpf, id_treino, usuario=None):
        aluno = self.repositorio.buscar_aluno_por_cpf(cpf)
        if not aluno:
            raise CadastroErro("Aluno não encontrado.")
        aluno._treinos = [t for t in aluno._treinos if t.get("id") != id_treino]
        self.repositorio.atualizar_aluno(aluno)
        return aluno

    def _desvincular_treino_de_alunos(self, id_treino):
        for aluno in self.repositorio.listar_alunos():
            antes = len(aluno._treinos)
            aluno._treinos = [
                t for t in aluno._treinos if t.get("id") != id_treino
            ]
            if len(aluno._treinos) != antes:
                self.repositorio.atualizar_aluno(aluno)

    @registrar_operacao("remover_treino_catalogo")
    def remover_catalogo(self, id_treino, usuario=None):
        if not id_treino:
            raise CadastroErro("Selecione um treino para remover.")
        if not self.repositorio.buscar_treino_catalogo(id_treino):
            raise CadastroErro("Treino não encontrado no catálogo.")
        self._desvincular_treino_de_alunos(id_treino)
        self.repositorio.remover_treino_catalogo(id_treino)
