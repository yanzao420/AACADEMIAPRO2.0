from calendar import monthrange
from datetime import datetime


def adicionar_meses(data_texto, quantidade_meses):
    """Soma meses a uma data DD/MM/AAAA mantendo o dia quando possível."""
    data = datetime.strptime(data_texto, "%d/%m/%Y").date()
    mes = data.month - 1 + quantidade_meses
    ano = data.year + mes // 12
    mes = mes % 12 + 1
    ultimo_dia = monthrange(ano, mes)[1]
    dia = min(data.day, ultimo_dia)
    return datetime(ano, mes, dia).strftime("%d/%m/%Y")
