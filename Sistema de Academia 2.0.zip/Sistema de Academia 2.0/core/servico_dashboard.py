from models.pagamento import Pagamento

from core.repositorio import RepositorioAcademia
from core.servico_pagamentos import ServicoPagamentos


class ServicoDashboard:

    def __init__(self, repositorio=None):
        self.repositorio = repositorio or RepositorioAcademia()
        self.pagamentos = ServicoPagamentos(self.repositorio)

    def obter_dados(self):
        self.pagamentos.sincronizar_mensalidades()
        return {
            "resumo": self._calcular_resumo(),
            "alertas": self._calcular_alertas(),
        }

    def obter_resumo(self):
        self.pagamentos.sincronizar_mensalidades()
        return self._calcular_resumo()

    def _calcular_resumo(self):
        alunos = self.repositorio.listar_alunos()
        ativos = [a for a in alunos if a.ativo]
        inativos = [a for a in alunos if not a.ativo]
        planos = self.repositorio.listar_planos()
        pagamentos = self.pagamentos.listar()

        pendentes = [p for p in pagamentos if p.status == Pagamento.STATUS_PENDENTE]
        atrasados = [p for p in pagamentos if p.status == Pagamento.STATUS_ATRASADO]
        pagos = [p for p in pagamentos if p.status == Pagamento.STATUS_PAGO]

        receita = sum(p.valor for p in pagos)

        return {
            "total_alunos": len(alunos),
            "alunos_ativos": len(ativos),
            "alunos_inativos": len(inativos),
            "total_planos": len(planos),
            "pagamentos_pendentes": len(pendentes),
            "pagamentos_atrasados": len(atrasados),
            "pagamentos_pagos": len(pagos),
            "receita_recebida": receita,
            "instrutores": len(self.repositorio.listar_instrutores()),
        }

    def _calcular_alertas(self):
        planos_validos = {p.id for p in self.repositorio.listar_planos()}
        sem_plano = 0
        for aluno in self.repositorio.listar_alunos(apenas_ativos=True):
            if not aluno.plano_id or aluno.plano_id not in planos_validos:
                sem_plano += 1

        cpfs_atraso = set()
        for pagamento in self.pagamentos.listar():
            if pagamento.status == Pagamento.STATUS_ATRASADO:
                cpfs_atraso.add(pagamento.aluno_cpf)

        return {
            "membros_sem_plano": sem_plano,
            "membros_com_atraso": len(cpfs_atraso),
        }

    @staticmethod
    def formatar_moeda(valor):
        return f"R$ {float(valor):.2f}".replace(".", ",")
