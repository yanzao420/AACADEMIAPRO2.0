from core.excecoes import AcessoNegado
from core.repositorio import RepositorioAcademia
from models.usuario import Usuario


class Autenticacao:

    def __init__(self, repositorio=None):
        self.repositorio = repositorio or RepositorioAcademia()
        self.usuarios = [
            Usuario("admin", "123", "admin"),
            Usuario("funcionario", "123", "funcionario"),
        ]

    def login(self, usuario, senha):
        usuario_limpo = (usuario or "").strip()
        senha_limpa = (senha or "").strip()

        for conta in self.usuarios:
            if conta.login == usuario_limpo and conta.verificar_senha(senha_limpa):
                return conta

        return self._login_aluno(usuario_limpo, senha_limpa)

    def _login_aluno(self, identificador, senha):
        cpf_limpo = "".join(filter(str.isdigit, identificador))
        if len(cpf_limpo) != 11:
            raise AcessoNegado("Usuário ou senha incorretos.")

        aluno = self.repositorio.buscar_aluno_por_cpf(cpf_limpo)
        if not aluno or not aluno.ativo:
            raise AcessoNegado("Usuário ou senha incorretos.")

        nascimento = aluno.data_nascimento.strip()
        nascimento_digitos = nascimento.replace("/", "")
        senhas_validas = {nascimento, nascimento_digitos, cpf_limpo[-4:]}

        if senha not in senhas_validas:
            raise AcessoNegado("Usuário ou senha incorretos.")

        return Usuario(
            login=aluno.nome.split()[0].lower(),
            senha="",
            nivel="aluno",
            cpf_aluno=aluno.cpf,
        )
