"""Exporta ficha de treinos do aluno para PDF."""
import os
from pathlib import Path

from fpdf import FPDF

from core.repositorio import RepositorioAcademia
from core.servico_instrutores import ServicoInstrutores
from core.servico_planos import ServicoPlanos
from core.servico_treinos import ServicoTreinos
from core.servico_usuarios import ServicoUsuarios

_SUBSTITUICOES_PDF = (
    ("\u2014", "-"),
    ("\u2013", "-"),
    ("\u2026", "..."),
    ("\u201c", '"'),
    ("\u201d", '"'),
    ("\u2018", "'"),
    ("\u2019", "'"),
)


def _pdf_text(texto, unicode_font=False):
    """Normaliza texto para o PDF."""
    if texto is None:
        return ""
    resultado = str(texto)
    for origem, destino in _SUBSTITUICOES_PDF:
        resultado = resultado.replace(origem, destino)
    if unicode_font:
        return resultado
    return resultado.encode("latin-1", errors="replace").decode("latin-1")


def _registrar_fontes(pdf):
    pasta = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    regular = pasta / "arial.ttf"
    negrito = pasta / "arialbd.ttf"
    italico = pasta / "ariali.ttf"
    if regular.exists():
        pdf.add_font("Arial", "", str(regular))
        if negrito.exists():
            pdf.add_font("Arial", "B", str(negrito))
        if italico.exists():
            pdf.add_font("Arial", "I", str(italico))
        return "Arial"
    return "Helvetica"


def _descricao_treino(treino, repositorio=None):
    if hasattr(treino, "descricao") and (treino.descricao or "").strip():
        return treino.descricao.strip()

    treino_id = treino.id if hasattr(treino, "id") else treino.get("id")
    if treino_id and repositorio:
        catalogo = repositorio.buscar_treino_catalogo(treino_id)
        if catalogo and (catalogo.get("descricao") or "").strip():
            return catalogo.get("descricao", "").strip()

    if hasattr(treino, "descricao"):
        local = (treino.descricao or "").strip()
    else:
        local = (treino.get("descricao") or "").strip()

    return local or "Sem descricao."


class ExportadorTreinoPDF(FPDF):
    def __init__(self):
        super().__init__()
        self.set_auto_page_break(auto=True, margin=18)
        self._familia = _registrar_fontes(self)
        self._unicode = self._familia == "Arial"

    def _fonte(self, estilo="", tamanho=10):
        self.set_font(self._familia, estilo, tamanho)

    def _escrever(self, largura, altura, texto, **kwargs):
        self.cell(largura, altura, _pdf_text(texto, self._unicode), **kwargs)

    def _escrever_multilinha(self, texto, altura=5):
        self.set_x(self.l_margin)
        self.multi_cell(self.epw, altura, _pdf_text(texto, self._unicode))


def exportar_treinos_aluno(aluno, treinos, caminho_saida):
    repositorio = RepositorioAcademia()
    servico_treinos = ServicoTreinos(repositorio)
    servico_planos = ServicoPlanos(repositorio)
    servico_instr = ServicoInstrutores(repositorio)

    treinos = servico_treinos.treinos_do_aluno(aluno.cpf) or treinos

    pdf = ExportadorTreinoPDF()
    pdf.add_page()

    pdf._fonte("B", 18)
    pdf._escrever(0, 10, "ACADEMIA PRO - Ficha de Treinos", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    pdf._fonte("B", 12)
    pdf._escrever(0, 8, aluno.nome, new_x="LMARGIN", new_y="NEXT")
    pdf._fonte("", 10)
    pdf._escrever(
        0,
        6,
        f"CPF: {ServicoUsuarios.formatar_cpf(aluno.cpf)}",
        new_x="LMARGIN",
        new_y="NEXT",
    )
    pdf._escrever(
        0,
        6,
        f"E-mail: {aluno.email}",
        new_x="LMARGIN",
        new_y="NEXT",
    )

    plano_txt = "Sem plano"
    if aluno.plano_id:
        plano = servico_planos.buscar(aluno.plano_id)
        if plano:
            plano_txt = f"{plano.nome} - {ServicoPlanos.formatar_valor(plano.valor)}"
    pdf._escrever(0, 6, f"Plano: {plano_txt}", new_x="LMARGIN", new_y="NEXT")

    instrutor_txt = servico_instr.nome_instrutor(aluno.instrutor_cpf)
    pdf._escrever(0, 6, f"Instrutor: {instrutor_txt}", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(6)

    pdf._fonte("B", 11)
    pdf._escrever(0, 8, f"Treinos vinculados ({len(treinos)})", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)

    if not treinos:
        pdf._fonte("", 10)
        pdf._escrever(0, 6, "Nenhum treino vinculado.", new_x="LMARGIN", new_y="NEXT")
    else:
        for indice, treino in enumerate(treinos, start=1):
            nome = treino.nome if hasattr(treino, "nome") else treino.get("nome", "Treino")
            duracao = (
                treino.duracao_minutos
                if hasattr(treino, "duracao_minutos")
                else treino.get("duracao_minutos", 60)
            )
            descricao = _descricao_treino(treino, repositorio)
            pdf._fonte("B", 10)
            pdf._escrever(0, 7, f"{indice}. {nome} ({duracao} min)", new_x="LMARGIN", new_y="NEXT")
            pdf._fonte("", 10)
            pdf._escrever_multilinha(f"Descricao: {descricao}")
            pdf.ln(3)

    pdf.ln(8)
    pdf._fonte("I", 9)
    pdf._escrever(
        0,
        6,
        "Documento gerado pelo Sistema Academia PRO.",
        new_x="LMARGIN",
        new_y="NEXT",
    )

    destino = Path(caminho_saida)
    destino.parent.mkdir(parents=True, exist_ok=True)
    pdf.output(str(destino))
    if not getattr(repositorio, "_usa_compartilhado", False):
        repositorio.close()
    return destino
