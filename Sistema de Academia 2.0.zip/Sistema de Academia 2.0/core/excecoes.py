class AcessoNegado(Exception):
    """Credenciais inválidas ou permissão insuficiente."""

    def __init__(self, mensagem="Acesso negado"):
        super().__init__(mensagem)


class ValidacaoErro(Exception):
    """Dados do formulário inválidos."""

    def __init__(self, mensagem):
        super().__init__(mensagem)


class CadastroErro(Exception):
    """Falha ao persistir ou regra de negócio do cadastro."""

    def __init__(self, mensagem):
        super().__init__(mensagem)
