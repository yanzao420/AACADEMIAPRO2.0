from models.pessoa import Pessoa


def gerar_relatorio_pessoas(pessoas: list[Pessoa]) -> str:
    if not pessoas:
        return "Nenhum registro encontrado."
    return "\n".join(p.apresentar() for p in pessoas)
