"""Catálogo fixo de treinos disponíveis para vincular aos alunos."""

CATALOGO_TREINOS_PADRAO = [
    {
        "id": "treino_peito_triceps",
        "nome": "Peito e Tríceps",
        "duracao_minutos": 60,
        "descricao": "Supino, crucifixo, tríceps na polia e paralelas.",
    },
    {
        "id": "treino_costas_biceps",
        "nome": "Costas e Bíceps",
        "duracao_minutos": 60,
        "descricao": "Puxada, remada, rosca direta e martelo.",
    },
    {
        "id": "treino_pernas",
        "nome": "Pernas Completo",
        "duracao_minutos": 70,
        "descricao": "Agachamento, leg press, cadeira extensora e flexora.",
    },
    {
        "id": "treino_ombros_abdomen",
        "nome": "Ombros e Abdômen",
        "duracao_minutos": 50,
        "descricao": "Desenvolvimento, elevação lateral e core.",
    },
    {
        "id": "treino_hiit",
        "nome": "HIIT 30 minutos",
        "duracao_minutos": 30,
        "descricao": "Circuito de alta intensidade com intervalos.",
    },
    {
        "id": "treino_funcional",
        "nome": "Funcional Full Body",
        "duracao_minutos": 45,
        "descricao": "Kettlebell, burpees, agachamento e prancha.",
    },
    {
        "id": "treino_gluteos",
        "nome": "Glúteos e Posterior",
        "duracao_minutos": 55,
        "descricao": "Hip thrust, stiff e abdução de quadril.",
    },
    {
        "id": "treino_cardio",
        "nome": "Cardio Esteira",
        "duracao_minutos": 40,
        "descricao": "Caminhada inclinada ou corrida moderada.",
    },
    {
        "id": "treino_crossfit",
        "nome": "Crossfit WOD",
        "duracao_minutos": 50,
        "descricao": "Workout do dia com força e condicionamento.",
    },
    {
        "id": "treino_bracos",
        "nome": "Braços",
        "duracao_minutos": 45,
        "descricao": "Bíceps, tríceps e antebraço em supersérie.",
    },
    {
        "id": "treino_core",
        "nome": "Core Intenso",
        "duracao_minutos": 35,
        "descricao": "Pranchas, abdominal e oblíquos.",
    },
    {
        "id": "treino_alongamento",
        "nome": "Alongamento e Mobilidade",
        "duracao_minutos": 30,
        "descricao": "Alongamento global e liberação miofascial.",
    },
    {
        "id": "treino_iniciante",
        "nome": "Iniciante — Adaptação",
        "duracao_minutos": 40,
        "descricao": "Máquinas guiadas e baixa carga técnica.",
    },
    {
        "id": "treino_avancado",
        "nome": "Avançado — Força",
        "duracao_minutos": 75,
        "descricao": "Agachamento, levantamento terra e supino pesado.",
    },
    {
        "id": "treino_full_body",
        "nome": "Full Body Equilibrado",
        "duracao_minutos": 60,
        "descricao": "Um exercício por grupo muscular na sessão.",
    },
]
