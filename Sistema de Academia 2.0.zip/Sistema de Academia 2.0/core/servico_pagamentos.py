from core.pagamentos.consultas import PagamentosConsultasMixin
from core.pagamentos.gerador_mensalidades import PagamentosGeradorMixin
from core.pagamentos.inadimplencia import PagamentosInadimplenciaMixin
from core.pagamentos.operacoes import PagamentosOperacoesMixin
from core.repositorio import RepositorioAcademia


class ServicoPagamentos(
    PagamentosConsultasMixin,
    PagamentosInadimplenciaMixin,
    PagamentosGeradorMixin,
    PagamentosOperacoesMixin,
):
    """Orquestra consultas, geração de mensalidades, inadimplência e operações."""

    def __init__(self, repositorio=None):
        self.repositorio = repositorio or RepositorioAcademia()

    def sincronizar_mensalidades(self):
        """Atualiza inadimplência e gera a próxima mensalidade quando aplicável."""
        self.gerar_mensalidades_iniciais_faltantes()
        self._desativar_inadimplentes()
        self.renovar_mensalidades_recorrentes()
