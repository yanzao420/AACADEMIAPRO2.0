import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.repositorio import RepositorioAcademia
from core.servico_planos import ServicoPlanos
from core.servico_usuarios import ServicoUsuarios
from models.usuario import Usuario


class TestServicos(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        self.repo = RepositorioAcademia(self.tmp.name)
        self.svc = ServicoUsuarios(self.repo)
        self.admin = Usuario("admin", "123", "admin")

    def tearDown(self):
        self.repo.close()
        os.unlink(self.tmp.name)

    def test_cadastrar_e_atualizar(self):
        self.svc.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            telefone="11999998888",
            usuario=self.admin,
        )
        self.assertEqual(len(self.svc.listar()), 1)
        self.svc.atualizar(
            cpf="52998224725",
            nome="Maria Silva Souza",
            data_nascimento="15/03/1990",
            email="maria2@test.com",
            telefone="11988887777",
            observacoes="Teste",
            usuario=self.admin,
        )
        aluno = self.svc.buscar_por_cpf("52998224725")
        self.assertEqual(aluno.nome, "Maria Silva Souza")
        self.assertEqual(aluno.observacoes, "Teste")

    def test_atualizar_plano_e_instrutor(self):
        from core.servico_instrutores import ServicoInstrutores

        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Trimestral", "300", "3", usuario=self.admin)
        instr = ServicoInstrutores(self.repo)
        instrutor = instr.listar()[0]

        self.svc.cadastrar(
            "Pedro Alves",
            "529.982.247-25",
            "01/01/1990",
            "pedro@test.com",
            usuario=self.admin,
        )
        self.svc.atualizar(
            cpf="52998224725",
            nome="Pedro Alves Silva",
            data_nascimento="01/01/1990",
            email="pedro@test.com",
            telefone="",
            observacoes="",
            plano_id=plano.id,
            instrutor_cpf=instrutor.cpf,
            treinos=[],
            ativo=True,
            usuario=self.admin,
        )
        aluno = self.svc.buscar_por_cpf("52998224725")
        self.assertEqual(aluno.nome, "Pedro Alves Silva")
        self.assertEqual(aluno.plano_id, plano.id)
        self.assertEqual(aluno.instrutor_cpf, instrutor.cpf)

    def test_alternar_status(self):
        self.svc.cadastrar(
            "Joao Pedro Lima",
            "529.982.247-25",
            "01/01/1995",
            "joao@test.com",
            usuario=self.admin,
        )
        self.svc.alternar_status("52998224725", usuario=self.admin)
        aluno = self.svc.buscar_por_cpf("52998224725")
        self.assertFalse(aluno.ativo)

    def test_plano_e_busca(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "150", "1", usuario=self.admin)
        self.svc.cadastrar(
            "Ana Costa Silva",
            "529.982.247-25",
            "10/05/1992",
            "ana@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="15/06/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )
        resultado = self.svc.listar(termo_busca="ana")
        self.assertEqual(len(resultado), 1)


if __name__ == "__main__":
    unittest.main()
