import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.repositorio import RepositorioAcademia
from core.servico_planos import ServicoPlanos
from core.servico_usuarios import ServicoUsuarios
from models.usuario import Usuario


class TestPlanos(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        self.repo = RepositorioAcademia(self.tmp.name)
        self.planos = ServicoPlanos(self.repo)
        self.usuarios = ServicoUsuarios(self.repo)
        self.admin = Usuario("admin", "123", "admin")

    def tearDown(self):
        self.repo.close()
        os.unlink(self.tmp.name)

    def test_remover_plano_limpa_membros_e_boletos(self):
        plano = self.planos.cadastrar("Mensal Teste", "99", "1", usuario=self.admin)
        self.usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="10/06/2026",
            usuario=self.admin,
        )
        self.assertEqual(len(self.repo.listar_pagamentos()), 1)

        self.planos.remover(plano.id, usuario=self.admin)

        self.assertIsNone(self.repo.buscar_plano_por_id(plano.id))
        aluno = self.repo.buscar_aluno_por_cpf("52998224725")
        self.assertIsNone(aluno.plano_id)
        self.assertEqual(len(self.repo.listar_pagamentos()), 0)


if __name__ == "__main__":
    unittest.main()
