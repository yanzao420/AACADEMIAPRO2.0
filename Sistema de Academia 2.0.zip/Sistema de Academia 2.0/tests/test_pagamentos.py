import os
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.repositorio import RepositorioAcademia
from core.servico_pagamentos import ServicoPagamentos
from core.servico_planos import ServicoPlanos
from core.servico_usuarios import ServicoUsuarios
from core.validacao import validar_duracao_meses
from models.pagamento import Pagamento
from models.usuario import Usuario


class TestPagamentosAuto(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        self.repo = RepositorioAcademia(self.tmp.name)
        self.admin = Usuario("admin", "123", "admin")

    def tearDown(self):
        self.repo.close()
        os.unlink(self.tmp.name)

    def test_duracao_um_mes_padrao(self):
        self.assertEqual(validar_duracao_meses(""), 1)
        self.assertEqual(validar_duracao_meses("1"), 1)

    def test_gerar_parcelas_ao_cadastrar(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "100", "1", usuario=self.admin)

        svc = ServicoUsuarios(self.repo)
        aluno = svc.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="10/06/2026",
            status_pagamento="pago",
            usuario=self.admin,
        )
        self.assertEqual(aluno.parcelas_geradas, 1)

        pagamentos = self.repo.listar_pagamentos()
        self.assertEqual(len(pagamentos), 1)
        self.assertEqual(pagamentos[0].status, Pagamento.STATUS_PAGO)
        self.assertEqual(pagamentos[0].vencimento, "10/06/2026")

    def test_gerar_tres_parcelas(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Trimestral", "250", "3", usuario=self.admin)

        svc = ServicoUsuarios(self.repo)
        aluno = svc.cadastrar(
            "Joao Pedro Lima",
            "529.982.247-25",
            "01/01/1995",
            "joao@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="01/06/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )
        self.assertEqual(aluno.parcelas_geradas, 3)
        vencimentos = [p.vencimento for p in self.repo.listar_pagamentos()]
        self.assertEqual(vencimentos, ["01/06/2026", "01/07/2026", "01/08/2026"])

    def test_renovar_gera_proxima_mensalidade_quando_paga(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)
        pagamentos_svc = ServicoPagamentos(self.repo)

        usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="10/04/2026",
            status_pagamento="pago",
            usuario=self.admin,
        )

        with patch("core.pagamentos.gerador_mensalidades.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 4, 11)
            mock_dt.strptime = datetime.strptime
            pagamentos_svc.sincronizar_mensalidades()

        vencimentos = [p.vencimento for p in self.repo.listar_pagamentos()]
        self.assertEqual(vencimentos, ["10/04/2026", "10/05/2026"])

    def test_nao_renovar_com_mensalidade_atrasada_e_desativa_aluno(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)
        pagamentos_svc = ServicoPagamentos(self.repo)

        usuarios.cadastrar(
            "Joao Pedro Lima",
            "390.533.447-05",
            "01/01/1995",
            "joao@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="10/03/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )

        with patch("core.pagamentos.gerador_mensalidades.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 4, 11)
            mock_dt.strptime = datetime.strptime
            pagamentos_svc.sincronizar_mensalidades()

        pagamentos = self.repo.listar_pagamentos()
        self.assertEqual(len(pagamentos), 1)
        self.assertEqual(pagamentos[0].status, Pagamento.STATUS_ATRASADO)

        aluno = self.repo.buscar_aluno_por_cpf("39053344705")
        self.assertFalse(aluno.ativo)

    def test_reativar_ao_quitar_atrasada(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)
        pagamentos_svc = ServicoPagamentos(self.repo)

        usuarios.cadastrar(
            "Ana Paula Souza",
            "153.509.460-56",
            "01/01/1995",
            "ana@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="10/03/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )

        with patch("core.pagamentos.gerador_mensalidades.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 4, 11)
            mock_dt.strptime = datetime.strptime
            pagamentos_svc.sincronizar_mensalidades()

        pagamento = self.repo.listar_pagamentos()[0]
        pagamentos_svc.marcar_como_pago(pagamento.id, usuario=self.admin)

        aluno = self.repo.buscar_aluno_por_cpf("15350946056")
        self.assertTrue(aluno.ativo)

    def test_marcar_pago_gera_proximo_boleto_instantaneo(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)
        pagamentos_svc = ServicoPagamentos(self.repo)

        usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="10/08/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )

        pagamento = self.repo.listar_pagamentos()[0]
        pagamentos_svc.marcar_como_pago(pagamento.id, usuario=self.admin)

        vencimentos = [p.vencimento for p in self.repo.listar_pagamentos()]
        self.assertEqual(vencimentos, ["10/08/2026", "10/09/2026"])

    def test_marcar_pago_nao_duplica_proximo_boleto(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)
        pagamentos_svc = ServicoPagamentos(self.repo)

        usuarios.cadastrar(
            "Joao Pedro Lima",
            "390.533.447-05",
            "01/01/1995",
            "joao@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="10/08/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )

        pagamento = self.repo.listar_pagamentos()[0]
        pagamentos_svc.marcar_como_pago(pagamento.id, usuario=self.admin)
        pagamentos_svc.sincronizar_mensalidades()

        self.assertEqual(len(self.repo.listar_pagamentos()), 2)

    def test_mensal_gera_boleto_ao_vincular_plano(self):
        planos = ServicoPlanos(self.repo)
        mensal = planos.cadastrar("Mensal", "120", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)

        usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            usuario=self.admin,
        )
        self.assertEqual(len(self.repo.listar_pagamentos()), 0)

        usuarios.atualizar(
            cpf="529.982.247-25",
            nome="Maria Silva Santos",
            data_nascimento="15/03/1990",
            email="maria@test.com",
            plano_id=mensal.id,
            data_primeiro_vencimento="10/06/2026",
            usuario=self.admin,
        )

        pagamentos = self.repo.listar_pagamentos()
        self.assertEqual(len(pagamentos), 1)
        self.assertEqual(pagamentos[0].plano_id, mensal.id)
        self.assertIn("Mensal", pagamentos[0].descricao)

    def test_sync_gera_boleto_mensal_sem_parcelas(self):
        planos = ServicoPlanos(self.repo)
        mensal = planos.cadastrar("Mensal", "120", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)
        pagamentos_svc = ServicoPagamentos(self.repo)

        aluno = usuarios.cadastrar(
            "Joao Pedro Lima",
            "529.982.247-25",
            "01/01/1995",
            "joao@test.com",
            usuario=self.admin,
        )
        aluno.plano_id = mensal.id
        self.repo.atualizar_aluno(aluno)
        self.assertEqual(len(self.repo.listar_pagamentos()), 0)

        pagamentos_svc.sincronizar_mensalidades()

        pagamentos = self.repo.listar_pagamentos()
        self.assertEqual(len(pagamentos), 1)
        self.assertEqual(pagamentos[0].plano_id, mensal.id)

    def test_trocar_plano_remove_antigos_e_gera_novos(self):
        planos = ServicoPlanos(self.repo)
        plano_a = planos.cadastrar("Mensal A", "100", "1", usuario=self.admin)
        plano_b = planos.cadastrar("Mensal B", "150", "2", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)

        usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            plano_id=plano_a.id,
            data_primeiro_vencimento="10/06/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )
        self.assertEqual(len(self.repo.listar_pagamentos()), 1)

        usuarios.atualizar(
            cpf="529.982.247-25",
            nome="Maria Silva Santos",
            data_nascimento="15/03/1990",
            email="maria@test.com",
            plano_id=plano_b.id,
            data_primeiro_vencimento="15/07/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )

        pagamentos = self.repo.listar_pagamentos()
        self.assertEqual(len(pagamentos), 2)
        self.assertTrue(all(p.plano_id == plano_b.id for p in pagamentos))
        self.assertEqual(
            sorted(p.vencimento for p in pagamentos),
            ["15/07/2026", "15/08/2026"],
        )

    def test_remover_plano_remove_boletos(self):
        planos = ServicoPlanos(self.repo)
        plano = planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        usuarios = ServicoUsuarios(self.repo)

        usuarios.cadastrar(
            "Joao Pedro Lima",
            "529.982.247-25",
            "01/01/1995",
            "joao@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="01/06/2026",
            status_pagamento="pendente",
            usuario=self.admin,
        )
        self.assertEqual(len(self.repo.listar_pagamentos()), 1)

        usuarios.atualizar(
            cpf="529.982.247-25",
            nome="Joao Pedro Lima",
            data_nascimento="01/01/1995",
            email="joao@test.com",
            plano_id=None,
            usuario=self.admin,
        )

        self.assertEqual(len(self.repo.listar_pagamentos()), 0)
        aluno = self.repo.buscar_aluno_por_cpf("52998224725")
        self.assertIsNone(aluno.plano_id)


if __name__ == "__main__":
    unittest.main()
