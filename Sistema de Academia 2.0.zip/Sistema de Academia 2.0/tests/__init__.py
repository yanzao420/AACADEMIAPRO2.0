"""Testes automatizados (unittest)."""
