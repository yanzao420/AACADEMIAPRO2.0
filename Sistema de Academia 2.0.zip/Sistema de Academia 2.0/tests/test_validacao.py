import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.excecoes import ValidacaoErro
from core.validacao import (
    validar_cpf,
    validar_data_nascimento,
    validar_email,
    validar_nome,
    validar_telefone,
    validar_valor_monetario,
)


class TestValidacao(unittest.TestCase):

    def test_nome_valido(self):
        self.assertEqual(validar_nome("Maria Silva"), "Maria Silva")

    def test_nome_invalido(self):
        with self.assertRaises(ValidacaoErro):
            validar_nome("Maria")

    def test_cpf_valido(self):
        self.assertEqual(validar_cpf("529.982.247-25"), "52998224725")

    def test_email_valido(self):
        self.assertEqual(validar_email("Teste@Email.com"), "teste@email.com")

    def test_telefone_opcional(self):
        self.assertEqual(validar_telefone(""), "")

    def test_valor_monetario(self):
        self.assertEqual(validar_valor_monetario("99,90"), 99.9)

    def test_data_nascimento(self):
        self.assertEqual(validar_data_nascimento("15/03/1990"), "15/03/1990")


if __name__ == "__main__":
    unittest.main()
