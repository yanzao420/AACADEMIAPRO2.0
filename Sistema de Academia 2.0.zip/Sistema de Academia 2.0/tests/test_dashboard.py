import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.repositorio import RepositorioAcademia
from core.servico_dashboard import ServicoDashboard
from core.servico_planos import ServicoPlanos
from core.servico_usuarios import ServicoUsuarios
from models.usuario import Usuario


class TestDashboard(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        self.repo = RepositorioAcademia(self.tmp.name)
        self.dashboard = ServicoDashboard(self.repo)
        self.planos = ServicoPlanos(self.repo)
        self.usuarios = ServicoUsuarios(self.repo)
        self.admin = Usuario("admin", "123", "admin")

    def tearDown(self):
        self.repo.close()
        os.unlink(self.tmp.name)

    def test_resumo_separa_pendente_e_atrasado(self):
        plano = self.planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        self.usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="01/01/2020",
            status_pagamento="pendente",
            usuario=self.admin,
        )
        resumo = self.dashboard.obter_resumo()
        self.assertGreater(resumo["pagamentos_atrasados"], 0)
        self.assertEqual(resumo["pagamentos_pendentes"], 0)

    def test_alertas_sem_plano_e_com_atraso(self):
        plano = self.planos.cadastrar("Mensal", "100", "1", usuario=self.admin)
        self.usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            plano_id=plano.id,
            data_primeiro_vencimento="01/01/2020",
            status_pagamento="pendente",
            usuario=self.admin,
        )
        self.usuarios.cadastrar(
            "Joao Pedro Lima",
            "390.533.447-05",
            "01/01/1995",
            "joao@test.com",
            usuario=self.admin,
        )

        dados = self.dashboard.obter_dados()
        alertas = dados["alertas"]
        self.assertEqual(alertas["membros_sem_plano"], 1)
        self.assertEqual(alertas["membros_com_atraso"], 1)
        self.assertEqual(dados["resumo"]["receita_recebida"], 0)
        self.assertEqual(
            ServicoDashboard.formatar_moeda(dados["resumo"]["receita_recebida"]),
            "R$ 0,00",
        )


if __name__ == "__main__":
    unittest.main()
