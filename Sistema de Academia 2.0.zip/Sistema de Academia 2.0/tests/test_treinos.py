import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.repositorio import RepositorioAcademia
from core.servico_treinos import ServicoTreinos
from core.servico_usuarios import ServicoUsuarios
from models.usuario import Usuario


class TestTreinos(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        self.repo = RepositorioAcademia(self.tmp.name)
        self.treinos = ServicoTreinos(self.repo)
        self.usuarios = ServicoUsuarios(self.repo)
        self.admin = Usuario("admin", "123", "admin")

    def tearDown(self):
        self.repo.close()
        os.unlink(self.tmp.name)

    def test_remover_catalogo_desvincula_alunos(self):
        treino = self.treinos.cadastrar_catalogo(
            "Teste Peito",
            60,
            "Supino reto 4x10",
            usuario=self.admin,
        )
        self.usuarios.cadastrar(
            "Maria Silva Santos",
            "529.982.247-25",
            "15/03/1990",
            "maria@test.com",
            usuario=self.admin,
        )
        self.treinos.adicionar_treino_ao_aluno(
            "52998224725",
            treino.id,
            usuario=self.admin,
        )

        aluno = self.repo.buscar_aluno_por_cpf("52998224725")
        self.assertEqual(len(aluno.treinos), 1)

        self.treinos.remover_catalogo(treino.id, usuario=self.admin)

        self.assertIsNone(self.repo.buscar_treino_catalogo(treino.id))
        aluno = self.repo.buscar_aluno_por_cpf("52998224725")
        self.assertEqual(len(aluno.treinos), 0)


if __name__ == "__main__":
    unittest.main()
