import tkinter as tk
class TelaPlanos:
    def __init__(self,frame):
        tk.Label(frame,text='Planos').pack(pady=40)
