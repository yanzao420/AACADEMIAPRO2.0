import tkinter as tk
from interface.alunos import TelaAlunos
from interface.planos import TelaPlanos
from interface.pagamentos import TelaPagamentos

class Dashboard:
    def __init__(self,root,usuario):
        self.area=tk.Frame(root); self.area.pack(expand=True,fill='both')
        for nome,tela in [('Alunos',TelaAlunos),('Planos',TelaPlanos),('Pagamentos',TelaPagamentos)]:
            tk.Button(self.area,text=nome,command=lambda t=tela:self.abrir(t)).pack(pady=10)
    def abrir(self,tela):
        for w in self.area.winfo_children(): w.destroy()
        tela(self.area)
