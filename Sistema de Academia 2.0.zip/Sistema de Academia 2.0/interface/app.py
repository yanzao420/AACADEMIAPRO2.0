import tkinter as tk
from interface.login import TelaLogin

class App:
    def __init__(self):
        self.root=tk.Tk()
        self.root.title('Sistema Academia PRO')
        self.root.geometry('900x600')
        TelaLogin(self.root)
        self.root.mainloop()
