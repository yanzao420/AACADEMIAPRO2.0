import tkinter as tk
class TelaPagamentos:
    def __init__(self,frame):
        tk.Label(frame,text='Pagamentos').pack(pady=40)
