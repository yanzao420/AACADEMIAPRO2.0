import tkinter as tk

class TelaAlunos:
    def __init__(self,frame):
        tk.Label(frame,text='Cadastro de Alunos',font=('Arial',20)).pack(pady=20)
        tk.Entry(frame).pack()
        tk.Button(frame,text='Cadastrar').pack(pady=10)
