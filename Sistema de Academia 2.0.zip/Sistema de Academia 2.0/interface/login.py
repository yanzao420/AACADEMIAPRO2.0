import tkinter as tk
from tkinter import messagebox
try:
 from core.autenticacao import Autenticacao
except Exception:
 Autenticacao=None
from interface.dashboard import Dashboard

class TelaLogin:
    def __init__(self,root):
        self.root=root
        self.frame=tk.Frame(root); self.frame.pack(expand=True)
        tk.Label(self.frame,text='ACADEMIA PRO',font=('Arial',24,'bold')).pack(pady=20)
        self.usuario=tk.Entry(self.frame); self.usuario.pack()
        self.senha=tk.Entry(self.frame,show='*'); self.senha.pack()
        tk.Button(self.frame,text='Entrar',command=self.entrar).pack(pady=20)
    def entrar(self):
        try:
            user=Autenticacao().login(self.usuario.get(),self.senha.get())
            self.frame.destroy(); Dashboard(self.root,user)
        except Exception as e: messagebox.showerror('Erro',str(e))
